# Phase 4 checklist-to-code coverage

This is a code-coverage map, not a hosted acceptance result.

| Phase 4 area | Primary implementation |
|---|---|
| Centralized V2 API/data layer | `frontend/src/api/v2Client.js`, `customerApi.js` |
| URL-synchronized filters | `frontend/src/lib/searchState.js` |
| Liveaboard search | `CustomerSearchPage.jsx`, `/explore/liveaboards/index.js` |
| Resort search | `CustomerSearchPage.jsx`, `/explore/resorts/index.js` |
| Mobile filter drawer | `FilterDrawer.jsx`, `SearchFilters.jsx` |
| Search result cards | `ProductCard.jsx`, `SearchResults.jsx` |
| Price/offer presentation | `PriceDisplay.jsx`, `OfferBadge.jsx` |
| Availability presentation | `AvailabilityBadge.jsx` |
| Liveaboard detail | `CustomerDetailPage.jsx`, `ItineraryList.jsx`, `DepartureTable.jsx` |
| Resort detail | `CustomerDetailPage.jsx`, `ResortInventory.jsx` |
| Enquiry context | `EnquiryForm.jsx`, `CustomerDetailPage.jsx` |
| Responsive/mobile departure presentation | `DepartureTable.jsx` |
| Sticky mobile CTA | `MobileStickyCTA.jsx` |
| Media URL/CDN-ready presentation | `ImageGallery.jsx`, `customerView.js` |
| Curated SEO collections | `/discover/[collection].js` |
| Faceted noindex handling | `CustomerSearchPage.jsx`, `searchState.js` |
| Installable PWA | `manifest.webmanifest`, icons, `PwaRegistrar.jsx` |
| Freshness-safe offline behavior | `public/sw.js`, `offline.html`, backend `cachePolicy.js` |
| Server query normalization/pagination/sort allowlists | backend `publicQuery.js` |
| Integration with accepted Phase 3 services | backend `publicRouterFactory.js`, `INTEGRATION.md` |
| Phase 4 backend unit tests | `backend/test/phase4/*.test.js` |

## Items that still require hosted integration evidence

The following cannot be marked PASS until the overlay is applied to the accepted Phase 3 checkout and deployed:

- exact Phase 3 service imports/mounts;
- MongoDB/server-side query behavior against staging data;
- Phase 1–3 regression suite;
- production Next.js build;
- Render deployment identity;
- enquiry email/notification workflow;
- browser/mobile visual acceptance;
- PWA installability in a real browser;
- SEO metadata/indexation inspection on hosted URLs.
