const VERSION='deeparture-p4-v1';
const STATIC_CACHE=`${VERSION}-static`;
const SHELL=['/manifest.webmanifest','/icons/icon-192.png','/icons/icon-512.png','/offline.html'];
self.addEventListener('install',(event)=>event.waitUntil(caches.open(STATIC_CACHE).then((c)=>c.addAll(SHELL)).then(()=>self.skipWaiting())));
self.addEventListener('activate',(event)=>event.waitUntil(caches.keys().then((keys)=>Promise.all(keys.filter((k)=>k.startsWith('deeparture-')&&!k.startsWith(VERSION)).map((k)=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',(event)=>{
  const req=event.request; if(req.method!=='GET') return;
  const url=new URL(req.url);
  if(url.origin!==self.location.origin) return;
  // Never cache API/search/pricing/availability/enquiry responses.
  if(url.pathname.startsWith('/api/')||url.pathname.includes('/enquiries')) return;
  if(req.mode==='navigate'){
    event.respondWith(fetch(req).catch(()=>caches.match('/offline.html'))); return;
  }
  if(['style','script','font','image'].includes(req.destination)){
    event.respondWith(caches.match(req).then((cached)=>cached||fetch(req).then((res)=>{if(res.ok){const copy=res.clone();caches.open(STATIC_CACHE).then((c)=>c.put(req,copy));}return res;}))); 
  }
});
