import { apiRequest, normalizePaged } from './v2Client';

export async function searchLiveaboards(query, options = {}) {
  return normalizePaged(await apiRequest('/v2/liveaboards', { query, ...options }));
}

export async function searchResorts(query, options = {}) {
  return normalizePaged(await apiRequest('/v2/resorts', { query, ...options }));
}

export function getLiveaboard(slug, options = {}) {
  return apiRequest(`/v2/liveaboards/${encodeURIComponent(slug)}`, options);
}

export function getResort(slug, options = {}) {
  return apiRequest(`/v2/resorts/${encodeURIComponent(slug)}`, options);
}

export async function searchDepartures(query, options = {}) {
  return normalizePaged(await apiRequest('/v2/departures', { query, ...options }));
}

export function getAttributes(options = {}) {
  return apiRequest('/v2/attributes', options);
}

export function submitEnquiry(body, options = {}) {
  return apiRequest('/v2/enquiries', { method: 'POST', body, ...options });
}
