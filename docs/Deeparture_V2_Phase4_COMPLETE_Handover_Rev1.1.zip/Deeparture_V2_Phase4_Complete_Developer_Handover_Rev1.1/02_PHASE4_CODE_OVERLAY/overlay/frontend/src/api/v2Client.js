const API_BASE = (process.env.NEXT_PUBLIC_API_URL || '').replace(/\/$/, '');

export class ApiError extends Error {
  constructor(message, { status = 0, code = 'API_ERROR', details = null } = {}) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

function buildUrl(path, query) {
  const url = `${API_BASE}${path.startsWith('/') ? '' : '/'}${path}`;
  if (!query) return url;
  const params = new URLSearchParams();
  Object.entries(query).forEach(([key, value]) => {
    if (value === undefined || value === null || value === '') return;
    if (Array.isArray(value)) {
      value.filter(Boolean).forEach((item) => params.append(key, String(item)));
      return;
    }
    params.set(key, String(value));
  });
  const suffix = params.toString();
  return suffix ? `${url}?${suffix}` : url;
}

export async function apiRequest(path, { query, method = 'GET', body, signal, headers = {}, cache = 'no-store' } = {}) {
  const response = await fetch(buildUrl(path, query), {
    method,
    signal,
    cache,
    headers: {
      Accept: 'application/json',
      ...(body ? { 'Content-Type': 'application/json' } : {}),
      ...headers,
    },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });

  const type = response.headers.get('content-type') || '';
  const payload = type.includes('application/json') ? await response.json() : null;
  if (!response.ok) {
    throw new ApiError(payload?.message || `Request failed (${response.status})`, {
      status: response.status,
      code: payload?.code || 'HTTP_ERROR',
      details: payload?.details || null,
    });
  }
  return payload;
}

export function normalizePaged(payload) {
  if (Array.isArray(payload)) {
    return { items: payload, page: 1, pageSize: payload.length, total: payload.length, totalPages: 1 };
  }
  const items = payload?.items || payload?.results || payload?.data || [];
  const page = Number(payload?.page || payload?.pagination?.page || 1);
  const pageSize = Number(payload?.pageSize || payload?.pagination?.pageSize || items.length || 24);
  const total = Number(payload?.total ?? payload?.pagination?.total ?? items.length);
  const totalPages = Number(payload?.totalPages || payload?.pagination?.totalPages || Math.max(1, Math.ceil(total / Math.max(pageSize, 1))));
  return { ...payload, items, page, pageSize, total, totalPages };
}
