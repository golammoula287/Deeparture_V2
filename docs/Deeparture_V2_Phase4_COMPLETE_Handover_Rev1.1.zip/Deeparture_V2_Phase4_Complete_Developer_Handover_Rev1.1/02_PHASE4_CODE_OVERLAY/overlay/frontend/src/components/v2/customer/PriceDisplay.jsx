import React from 'react';
import { Box, Chip, Stack, Typography } from '@mui/material';
import { pickEffectivePrice } from '../../../lib/customerView';

function money(amount, currency) {
  if (!Number.isFinite(Number(amount))) return null;
  try { return new Intl.NumberFormat(undefined, { style: 'currency', currency, maximumFractionDigits: 0 }).format(Number(amount)); }
  catch { return `${currency || ''} ${Number(amount).toLocaleString()}`.trim(); }
}

export default function PriceDisplay({ value, prefix = 'From', compact = false }) {
  const p = pickEffectivePrice({ effectivePrice: value }) || pickEffectivePrice(value || {});
  if (!p || !Number.isFinite(p.amount)) return <Typography variant="body2">Price on request</Typography>;
  return <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap">
    <Box>
      <Typography variant={compact ? 'body1' : 'h6'} component="span" fontWeight={700}>{prefix} {money(p.amount, p.currency)}</Typography>
      {p.rackAmount && p.rackAmount > p.amount ? <Typography component="span" sx={{ ml: 1, textDecoration: 'line-through', opacity: .65 }}>{money(p.rackAmount, p.currency)}</Typography> : null}
    </Box>
    {p.hasOffer && p.offerLabel ? <Chip size="small" label={p.offerLabel} color="success" /> : null}
  </Stack>;
}
