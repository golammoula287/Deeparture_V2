import React from 'react';
import { Box, Chip, Stack, Typography } from '@mui/material';
export default function ItineraryList({ itineraries = [] }) {
  if (!itineraries.length) return null;
  return <Box><Typography variant="h5" component="h2" gutterBottom>Itineraries</Typography><Stack spacing={1.5}>{itineraries.map((it)=>{const nights=it.nights ?? it.durationNights; const route=[it.embarkation?.name||it.embarkation, it.disembarkation?.name||it.disembarkation].filter(Boolean).join(' → '); return <Box key={it._id||it.id||it.slug||it.name} sx={{p:2,border:1,borderColor:'divider',borderRadius:2}}><Stack direction="row" justifyContent="space-between" gap={1} flexWrap="wrap"><Typography fontWeight={700}>{it.name||it.title||'Itinerary'}</Typography>{nights!=null?<Chip size="small" label={`${nights} nights`} />:null}</Stack>{route?<Typography variant="body2" color="text.secondary" sx={{mt:.5}}>{route}</Typography>:null}{it.summary||it.description?<Typography variant="body2" sx={{mt:1}}>{it.summary||it.description}</Typography>:null}</Box>;})}</Stack></Box>;
}
