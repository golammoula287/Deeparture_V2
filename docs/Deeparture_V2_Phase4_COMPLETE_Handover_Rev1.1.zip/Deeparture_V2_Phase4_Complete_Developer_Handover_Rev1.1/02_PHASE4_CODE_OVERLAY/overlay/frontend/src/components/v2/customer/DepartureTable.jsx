import React from 'react';
import { Box, Button, Card, CardContent, Stack, Table, TableBody, TableCell, TableHead, TableRow, Typography, useMediaQuery, useTheme } from '@mui/material';
import PriceDisplay from './PriceDisplay';
import AvailabilityBadge from './AvailabilityBadge';
function fmt(v){ if(!v) return '—'; const d=new Date(v); return Number.isNaN(d.valueOf()) ? String(v) : d.toLocaleDateString(); }
export default function DepartureTable({ departures = [], onEnquire }) {
  const theme=useTheme(); const mobile=useMediaQuery(theme.breakpoints.down('md'));
  if(!departures.length) return <Typography color="text.secondary">No current departures are published. Enquire for availability.</Typography>;
  if(mobile) return <Stack spacing={1.5}>{departures.map((d)=><Card key={d._id||d.id} variant="outlined"><CardContent><Typography fontWeight={700}>{d.itinerary?.name || d.itineraryName || 'Departure'}</Typography><Typography variant="body2" sx={{mb:1}}>{fmt(d.startDate)} – {fmt(d.endDate)}</Typography><Stack spacing={1}><PriceDisplay value={d.effectivePrice || d} compact/><AvailabilityBadge value={d.availability || d.resolvedAvailability}/><Button variant="outlined" onClick={()=>onEnquire?.(d)}>Enquire</Button></Stack></CardContent></Card>)}</Stack>;
  return <Box sx={{ overflowX:'auto' }}><Table><TableHead><TableRow><TableCell>Dates</TableCell><TableCell>Itinerary</TableCell><TableCell>Price</TableCell><TableCell>Availability</TableCell><TableCell /></TableRow></TableHead><TableBody>{departures.map((d)=><TableRow key={d._id||d.id}><TableCell>{fmt(d.startDate)} – {fmt(d.endDate)}</TableCell><TableCell>{d.itinerary?.name || d.itineraryName || '—'}</TableCell><TableCell><PriceDisplay value={d.effectivePrice || d} compact/></TableCell><TableCell><AvailabilityBadge value={d.availability || d.resolvedAvailability}/></TableCell><TableCell><Button onClick={()=>onEnquire?.(d)}>Enquire</Button></TableCell></TableRow>)}</TableBody></Table></Box>;
}
