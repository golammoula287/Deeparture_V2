import React from 'react';
import Head from 'next/head';
import { Box, Chip, Container, Divider, Grid, Stack, Typography } from '@mui/material';
import ImageGallery from './ImageGallery';
import PriceDisplay from './PriceDisplay';
import AvailabilityBadge from './AvailabilityBadge';
import DepartureTable from './DepartureTable';
import EnquiryForm from './EnquiryForm';
import MobileStickyCTA from './MobileStickyCTA';
import ItineraryList from './ItineraryList';
import ResortInventory from './ResortInventory';
import { pickName, pickLocation, pickEffectivePrice, pickAvailability, pickAttributes } from '../../../lib/customerView';

export default function CustomerDetailPage({ item, kind='liveaboard' }) {
  const enquiryRef=React.useRef(null); const [selected,setSelected]=React.useState(null);
  const name=pickName(item), location=pickLocation(item), price=pickEffectivePrice(item), availability=pickAvailability(item);
  const canonical=`https://deeparture.travel/${kind==='resort'?'resorts':'liveaboards'}/${item.slug}`;
  const scroll=(context)=>{setSelected(context||null); setTimeout(()=>enquiryRef.current?.scrollIntoView({behavior:'smooth',block:'start'}),0)};
  const attrs=[...pickAttributes(item,'facilities'),...pickAttributes(item,'dietary'),...pickAttributes(item,'accessibility')].slice(0,20);
  const departures=item.departures||item.upcomingDepartures||[];
  const itineraries=item.itineraries||item.itinerarySummaries||[];
  return <><Head><title>{name} | Deeparture</title><meta name="description" content={`${name}${location?` in ${location}`:''}. View diving, pricing, availability and enquire with Deeparture.`}/><link rel="canonical" href={canonical}/><link rel="manifest" href="/manifest.webmanifest"/></Head>
    <Container maxWidth="lg" sx={{py:{xs:3,md:5},pb:{xs:10,md:5}}}><Stack spacing={4}>
      <Box><Typography variant="h2" component="h1" sx={{fontSize:{xs:'2.2rem',md:'3.5rem'}}}>{name}</Typography>{location?<Typography variant="h6" color="text.secondary">{location}</Typography>:null}</Box>
      <ImageGallery item={item}/>
      <Grid container spacing={4}><Grid item xs={12} md={8}><Stack spacing={3}>
        {item.description||item.summary?<Typography sx={{whiteSpace:'pre-line'}}>{item.description||item.summary}</Typography>:null}
        {(item.veganRating!=null||attrs.length)?<Box><Typography variant="h5" component="h2" gutterBottom>Features & suitability</Typography><Stack direction="row" useFlexGap flexWrap="wrap" gap={1}>{item.veganRating!=null?<Chip label={`Vegan Rating ${item.veganRating}/5`} color="success" variant="outlined"/>:null}{attrs.map((a)=><Chip key={String(a)} label={typeof a==='string'?a:(a.name||a.label||a.value)} variant="outlined"/>)}</Stack></Box>:null}
        {kind==='liveaboard'?<ItineraryList itineraries={itineraries}/>:null}
        {kind==='liveaboard'?<Box><Typography variant="h5" component="h2" gutterBottom>Upcoming departures</Typography><DepartureTable departures={departures} onEnquire={scroll}/></Box>:null}
        {kind==='resort'?<ResortInventory item={item}/>:null}
      </Stack></Grid><Grid item xs={12} md={4}><Box sx={{position:{md:'sticky'},top:{md:24},p:2.5,border:1,borderColor:'divider',borderRadius:2}}><Stack spacing={1.5}><PriceDisplay value={price}/><AvailabilityBadge value={availability} showFreshness/><Divider/><Typography>Need current availability or help choosing dates?</Typography><Box component="button" onClick={()=>scroll(null)} sx={{border:0,borderRadius:1,p:1.5,bgcolor:'primary.main',color:'primary.contrastText',font:'inherit',fontWeight:700,cursor:'pointer'}}>Enquire now</Box></Stack></Box></Grid></Grid>
      <Box ref={enquiryRef}><EnquiryForm context={{ kind, listingId:item._id||item.id, slug:item.slug, departureId:selected?._id||selected?.id||null, packageId:selected?.packageId||null }}/></Box>
    </Stack></Container><MobileStickyCTA onClick={()=>scroll(null)}/>
  </>;
}
