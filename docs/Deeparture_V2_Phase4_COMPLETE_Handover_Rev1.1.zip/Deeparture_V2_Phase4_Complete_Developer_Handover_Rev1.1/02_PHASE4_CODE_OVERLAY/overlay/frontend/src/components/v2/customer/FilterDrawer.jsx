import React from 'react';
import { Box, Button, Drawer, IconButton, Typography } from '@mui/material';
import SearchFilters from './SearchFilters';
export default function FilterDrawer(props) {
  const [open,setOpen]=React.useState(false);
  return <>
    <Button variant="outlined" onClick={()=>setOpen(true)} fullWidth>Filters</Button>
    <Drawer anchor="bottom" open={open} onClose={()=>setOpen(false)} PaperProps={{ sx:{ maxHeight:'92vh', borderTopLeftRadius:16, borderTopRightRadius:16 } }}>
      <Box sx={{ p:2, overflowY:'auto' }}><Box sx={{ display:'flex', alignItems:'center', justifyContent:'space-between', mb:2 }}><Typography variant="h6">Filters</Typography><IconButton onClick={()=>setOpen(false)} aria-label="Close filters">×</IconButton></Box><SearchFilters {...props} /><Button variant="contained" fullWidth sx={{ mt:2 }} onClick={()=>setOpen(false)}>Show results</Button></Box>
    </Drawer>
  </>;
}
