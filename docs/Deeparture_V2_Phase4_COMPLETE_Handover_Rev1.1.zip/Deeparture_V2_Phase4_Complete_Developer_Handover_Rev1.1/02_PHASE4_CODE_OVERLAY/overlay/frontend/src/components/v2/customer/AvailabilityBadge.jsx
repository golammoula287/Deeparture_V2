import React from 'react';
import { Chip, Tooltip } from '@mui/material';
import { pickAvailability } from '../../../lib/customerView';

const MAP = {
  available: ['Available', 'success'], limited: ['Limited', 'warning'], on_request: ['On request', 'default'],
  sold_out: ['Sold out', 'error'], waitlist: ['Waitlist', 'warning'], stale: ['Check availability', 'default'], unknown: ['Check availability', 'default'],
};

export default function AvailabilityBadge({ value, showFreshness = false }) {
  const a = pickAvailability({ availability: value });
  const [label, color] = MAP[a.status] || MAP.unknown;
  const title = showFreshness && a.updatedAt ? `Last updated ${new Date(a.updatedAt).toLocaleString()}` : '';
  const chip = <Chip size="small" label={a.availableUnits != null && a.status === 'available' ? `${label} · ${a.availableUnits}` : label} color={color} variant={color === 'default' ? 'outlined' : 'filled'} />;
  return title ? <Tooltip title={title}>{chip}</Tooltip> : chip;
}
