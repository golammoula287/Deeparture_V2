import React from 'react';
import Link from 'next/link';
import { Box, Card, CardActionArea, CardContent, CardMedia, Chip, Stack, Typography } from '@mui/material';
import PriceDisplay from './PriceDisplay';
import AvailabilityBadge from './AvailabilityBadge';
import { pickName, pickSlug, pickImages, pickLocation, pickEffectivePrice, pickAvailability } from '../../../lib/customerView';

export default function ProductCard({ item, kind = 'liveaboard' }) {
  const name = pickName(item), slug = pickSlug(item), images = pickImages(item), location = pickLocation(item);
  const href = `/${kind === 'resort' ? 'resorts' : 'liveaboards'}/${encodeURIComponent(slug)}`;
  const price = pickEffectivePrice(item), availability = pickAvailability(item);
  const match=(item?.matchingDepartures||item?.departures||[])[0];
  const route=match?.itinerary?.name||match?.itineraryName||item?.routeName||item?.itineraryName||'';
  const nights=match?.nights||item?.nights||item?.tripLength||null;
  const dates=match?.startDate ? `${new Date(match.startDate).toLocaleDateString()}${match?.endDate?` – ${new Date(match.endDate).toLocaleDateString()}`:''}` : '';
  const tags = [item?.veganRating != null ? `Vegan ${item.veganRating}/5` : null, item?.nitrox === true ? 'Nitrox' : null, item?.photography === true ? 'Photography' : null].filter(Boolean);
  return <Card variant="outlined" sx={{ height: '100%' }}>
    <CardActionArea component={Link} href={href} sx={{ height: '100%', alignItems: 'stretch' }}>
      {images[0] ? <CardMedia component="img" image={images[0].url} alt={images[0].alt || name} loading="lazy" sx={{ aspectRatio: '16/10', objectFit: 'cover' }} /> : null}
      <CardContent>
        <Typography variant="h6" component="h2" fontWeight={700}>{name}</Typography>
        {location ? <Typography variant="body2" color="text.secondary">{location}</Typography> : null}
        {route ? <Typography variant="body2" sx={{ mt:.5 }}>{route}</Typography> : null}
        {(dates||nights) ? <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>{dates}{dates&&nights?' · ':''}{nights?`${nights} nights`:''}</Typography> : <Box sx={{mb:1}} />}
        <Stack direction="row" spacing={.75} flexWrap="wrap" useFlexGap sx={{ mb: 1 }}>{tags.map((t) => <Chip key={t} label={t} size="small" variant="outlined" />)}</Stack>
        <Stack spacing={1}><PriceDisplay value={price} compact /><AvailabilityBadge value={availability} /></Stack>
      </CardContent>
    </CardActionArea>
  </Card>;
}
