import React from 'react';
import { Box, Button } from '@mui/material';
export default function MobileStickyCTA({ label='Enquire', onClick }) { return <Box sx={{ display:{xs:'block',md:'none'}, position:'fixed', left:0, right:0, bottom:0, p:1.5, bgcolor:'background.paper', borderTop:1, borderColor:'divider', zIndex:1200 }}><Button variant="contained" fullWidth onClick={onClick}>{label}</Button></Box>; }
