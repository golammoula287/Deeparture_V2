import React from 'react';
import { Chip } from '@mui/material';
export default function OfferBadge({ offer }) {
  if (!offer || offer.active === false) return null;
  const label = offer.label || offer.name || offer.offerLabel;
  return label ? <Chip size="small" color="success" label={label} /> : null;
}
