import React from 'react';
import { Alert, Box, CircularProgress, Grid, Pagination, Stack, Typography } from '@mui/material';
import ProductCard from './ProductCard';
export default function SearchResults({ data, loading, error, kind, onPage }) {
  if (loading) return <Box sx={{ py:8, textAlign:'center' }}><CircularProgress aria-label="Loading results" /></Box>;
  if (error) return <Alert severity="error">{error.message || 'Could not load results.'}</Alert>;
  if (!data?.items?.length) return <Box sx={{ py:7, textAlign:'center' }}><Typography variant="h6">No matching results</Typography><Typography color="text.secondary">Try changing or clearing some filters.</Typography></Box>;
  return <Stack spacing={3}><Grid container spacing={2.5}>{data.items.map((item) => <Grid item xs={12} sm={6} lg={4} key={item._id || item.id || item.slug}><ProductCard item={item} kind={kind} /></Grid>)}</Grid>{data.totalPages > 1 ? <Pagination page={data.page} count={data.totalPages} onChange={(_,p)=>onPage(p)} sx={{ alignSelf:'center' }} /> : null}</Stack>;
}
