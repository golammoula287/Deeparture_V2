import React from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { Box, Container, Grid, MenuItem, Stack, TextField, Typography, useMediaQuery, useTheme } from '@mui/material';
import SearchFilters from './SearchFilters';
import FilterDrawer from './FilterDrawer';
import SearchResults from './SearchResults';
import { searchLiveaboards, searchResorts, getAttributes } from '../../../api/customerApi';
import { DEFAULT_PAGE_SIZE, filtersToRouterQuery, hasIndexSensitiveFilters, routerQueryToFilters } from '../../../lib/searchState';

function groupAttributes(payload){ const list=Array.isArray(payload)?payload:(payload?.items||payload?.data||[]); const out={facilities:[],dietary:[],accessibility:[]}; list.forEach((a)=>{const g=String(a.group||a.type||a.category||'').toLowerCase(); if(out[g]) out[g].push(a);}); return out; }

export default function CustomerSearchPage({ kind='liveaboard' }) {
  const router=useRouter(); const theme=useTheme(); const desktop=useMediaQuery(theme.breakpoints.up('md'));
  const [data,setData]=React.useState(null), [attrs,setAttrs]=React.useState({}), [loading,setLoading]=React.useState(false), [error,setError]=React.useState(null);
  const filters=React.useMemo(()=>({ page:1, pageSize:DEFAULT_PAGE_SIZE, sort:kind==='liveaboard'?'startDate':'name', ...routerQueryToFilters(router.query) }),[router.query,kind]);
  const title=kind==='liveaboard'?'Liveaboard diving':'Dive resorts';
  const update=React.useCallback((next)=>router.replace({ pathname:router.pathname, query:filtersToRouterQuery(next) },undefined,{shallow:true}),[router]);
  React.useEffect(()=>{ if(!router.isReady) return; const controller=new AbortController(); setLoading(true); setError(null); const fn=kind==='liveaboard'?searchLiveaboards:searchResorts; fn(filters,{signal:controller.signal}).then(setData).catch((e)=>{if(e.name!=='AbortError')setError(e)}).finally(()=>setLoading(false)); return ()=>controller.abort(); },[router.isReady,kind,JSON.stringify(filters)]);
  React.useEffect(()=>{ const controller=new AbortController(); getAttributes({signal:controller.signal}).then((r)=>setAttrs(groupAttributes(r))).catch(()=>{}); return ()=>controller.abort();},[]);
  const filtered=hasIndexSensitiveFilters(router.query);
  return <>
    <Head><title>{title} | Deeparture</title><meta name="description" content={`Search ${title.toLowerCase()} by destination, price, dietary, accessibility and availability.`}/>{filtered?<meta name="robots" content="noindex,follow"/>:null}<link rel="canonical" href={`https://deeparture.travel${router.pathname}`}/><link rel="manifest" href="/manifest.webmanifest"/></Head>
    <Container maxWidth="xl" sx={{ py:{xs:3,md:5} }}><Stack spacing={3}>
      <Box><Typography variant="h3" component="h1" sx={{fontSize:{xs:'2rem',md:'3rem'}}}>{title}</Typography><Typography color="text.secondary">Search structured Deeparture V2 inventory with server-side filters.</Typography></Box>
      <Box sx={{ display:'flex', gap:2, justifyContent:'space-between', alignItems:'center' }}>{!desktop?<FilterDrawer kind={kind} filters={filters} onChange={update} onClear={()=>update({page:1,pageSize:DEFAULT_PAGE_SIZE,sort:filters.sort})} attributes={attrs}/>:<Box/>}<TextField select size="small" label="Sort" value={filters.sort||''} onChange={(e)=>update({...filters,sort:e.target.value,page:1})} sx={{minWidth:180}}>{(kind==='liveaboard'?[['startDate','Departure date'],['priceAsc','Price: low to high'],['priceDesc','Price: high to low'],['veganRating','Vegan rating']]:[['name','Name'],['priceAsc','Price: low to high'],['priceDesc','Price: high to low'],['veganRating','Vegan rating']]).map(([v,l])=><MenuItem key={v} value={v}>{l}</MenuItem>)}</TextField></Box>
      <Grid container spacing={3}>{desktop?<Grid item md={3}><Box sx={{position:'sticky',top:24}}><SearchFilters kind={kind} filters={filters} onChange={update} onClear={()=>update({page:1,pageSize:DEFAULT_PAGE_SIZE,sort:filters.sort})} attributes={attrs}/></Box></Grid>:null}<Grid item xs={12} md={desktop?9:12}><SearchResults data={data} loading={loading} error={error} kind={kind} onPage={(page)=>update({...filters,page})}/></Grid></Grid>
    </Stack></Container>
  </>;
}
