import React from 'react';
export default function PwaRegistrar(){
  React.useEffect(()=>{
    if(!('serviceWorker' in navigator) || process.env.NODE_ENV!=='production') return;
    const register=()=>navigator.serviceWorker.register('/sw.js',{scope:'/'}).catch(()=>{});
    if(document.readyState==='complete') register(); else window.addEventListener('load',register,{once:true});
  },[]);
  return null;
}
