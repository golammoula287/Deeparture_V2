import React from 'react';
import { Alert, Button, Stack, TextField, Typography } from '@mui/material';
import { submitEnquiry } from '../../../api/customerApi';
export default function EnquiryForm({ context }) {
  const [form,setForm]=React.useState({ fullName:'', email:'', message:'' });
  const [state,setState]=React.useState({ sending:false, success:false, error:null });
  const set=(k,v)=>setForm((f)=>({...f,[k]:v}));
  async function send(e){ e.preventDefault(); setState({sending:true,success:false,error:null}); try { await submitEnquiry({ ...form, context }); setState({sending:false,success:true,error:null}); setForm({fullName:'',email:'',message:''}); } catch(error){ setState({sending:false,success:false,error}); } }
  return <Stack component="form" onSubmit={send} spacing={2} noValidate>
    <Typography variant="h5" component="h2">Enquire</Typography>
    {state.success ? <Alert severity="success">Thanks — your enquiry has been sent.</Alert> : null}
    {state.error ? <Alert severity="error">{state.error.message || 'Could not send your enquiry.'}</Alert> : null}
    <TextField required label="Name" autoComplete="name" value={form.fullName} onChange={(e)=>set('fullName',e.target.value)} />
    <TextField required type="email" label="Email" autoComplete="email" value={form.email} onChange={(e)=>set('email',e.target.value)} />
    <TextField required multiline minRows={4} label="Message" value={form.message} onChange={(e)=>set('message',e.target.value)} />
    <Button type="submit" variant="contained" disabled={state.sending || !form.fullName || !form.email || !form.message}>{state.sending ? 'Sending…' : 'Send enquiry'}</Button>
  </Stack>;
}
