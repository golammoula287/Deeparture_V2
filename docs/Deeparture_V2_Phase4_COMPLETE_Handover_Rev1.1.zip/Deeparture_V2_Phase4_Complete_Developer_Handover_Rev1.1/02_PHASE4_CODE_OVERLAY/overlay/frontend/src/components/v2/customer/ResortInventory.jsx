import React from 'react';
import { Box, Chip, Stack, Typography } from '@mui/material';
import PriceDisplay from './PriceDisplay';
import AvailabilityBadge from './AvailabilityBadge';
export default function ResortInventory({ item }) {
  const rooms=item.roomTypes||item.rooms||[]; const packages=item.packages||item.resortPackages||[]; const rates=item.ratePeriods||item.seasonalPricing||[];
  if(!rooms.length&&!packages.length&&!rates.length) return <Typography color="text.secondary">Current package details are available on request.</Typography>;
  return <Stack spacing={3}>
    {rooms.length?<Box><Typography variant="h5" component="h2" gutterBottom>Room types</Typography><Stack spacing={1}>{rooms.map((r)=><Box key={r._id||r.id||r.name} sx={{p:2,border:1,borderColor:'divider',borderRadius:2}}><Typography fontWeight={700}>{r.name||r.title}</Typography>{r.capacity?<Typography variant="body2">Capacity: {r.capacity}</Typography>:null}</Box>)}</Stack></Box>:null}
    {packages.length?<Box><Typography variant="h5" component="h2" gutterBottom>Packages</Typography><Stack spacing={1}>{packages.map((p)=><Box key={p._id||p.id||p.name} sx={{p:2,border:1,borderColor:'divider',borderRadius:2}}><Stack direction="row" justifyContent="space-between" gap={1} flexWrap="wrap"><Typography fontWeight={700}>{p.name||p.title}</Typography>{p.nights?<Chip size="small" label={`${p.nights} nights`} />:null}</Stack>{p.description?<Typography variant="body2" sx={{my:.5}}>{p.description}</Typography>:null}<PriceDisplay value={p.effectivePrice||p} compact/><AvailabilityBadge value={p.availability||p.resolvedAvailability}/></Box>)}</Stack></Box>:null}
    {rates.length?<Box><Typography variant="h5" component="h2" gutterBottom>Seasonal rates</Typography><Stack spacing={1}>{rates.map((r)=><Box key={r._id||r.id||`${r.startDate}-${r.endDate}`} sx={{p:2,border:1,borderColor:'divider',borderRadius:2}}><Typography variant="body2" color="text.secondary">{r.startDate?new Date(r.startDate).toLocaleDateString():''}{r.endDate?` – ${new Date(r.endDate).toLocaleDateString()}`:''}</Typography><PriceDisplay value={r.effectivePrice||r} compact/><AvailabilityBadge value={r.availability||r.resolvedAvailability}/></Box>)}</Stack></Box>:null}
  </Stack>;
}
