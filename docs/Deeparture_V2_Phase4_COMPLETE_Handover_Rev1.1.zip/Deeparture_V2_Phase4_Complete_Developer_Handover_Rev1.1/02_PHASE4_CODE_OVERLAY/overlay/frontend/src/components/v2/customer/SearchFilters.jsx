import React from 'react';
import { Accordion, AccordionDetails, AccordionSummary, Box, Button, Checkbox, FormControlLabel, Grid, MenuItem, Slider, TextField, Typography } from '@mui/material';

const comma = (v) => Array.isArray(v) ? v : v ? String(v).split(',') : [];
function toggle(list, value) { return list.includes(value) ? list.filter((x) => x !== value) : [...list, value]; }

export default function SearchFilters({ kind = 'liveaboard', filters, onChange, onClear, attributes = {} }) {
  const set = (key, value) => onChange({ ...filters, [key]: value, page: 1 });
  const facilities = attributes.facilities || [];
  const dietary = attributes.dietary || [];
  const accessibility = attributes.accessibility || [];
  return <Box component="form" onSubmit={(e) => e.preventDefault()} aria-label={`${kind} search filters`}>
    <Grid container spacing={2}>
      <Grid item xs={12}><TextField fullWidth label="Destination" value={filters.destination || ''} onChange={(e) => set('destination', e.target.value)} /></Grid>
      {kind === 'liveaboard' ? <>
        <Grid item xs={6}><TextField fullWidth type="date" label="From" InputLabelProps={{ shrink: true }} value={filters.startFrom || ''} onChange={(e) => set('startFrom', e.target.value)} /></Grid>
        <Grid item xs={6}><TextField fullWidth type="date" label="To" InputLabelProps={{ shrink: true }} value={filters.startTo || ''} onChange={(e) => set('startTo', e.target.value)} /></Grid>
        <Grid item xs={12}><TextField fullWidth label="Embarkation" value={filters.embarkation || ''} onChange={(e) => set('embarkation', e.target.value)} /></Grid>
      </> : null}
      <Grid item xs={6}><TextField fullWidth type="number" label="Min price" value={filters.minPrice ?? ''} onChange={(e) => set('minPrice', e.target.value)} /></Grid>
      <Grid item xs={6}><TextField fullWidth type="number" label="Max price" value={filters.maxPrice ?? ''} onChange={(e) => set('maxPrice', e.target.value)} /></Grid>
      {kind === 'liveaboard' ? <>
        <Grid item xs={6}><TextField fullWidth type="number" label="Min nights" value={filters.minNights ?? ''} onChange={(e) => set('minNights', e.target.value)} /></Grid>
        <Grid item xs={6}><TextField fullWidth type="number" label="Max nights" value={filters.maxNights ?? ''} onChange={(e) => set('maxNights', e.target.value)} /></Grid>
      </> : null}
      <Grid item xs={12}><Typography gutterBottom>Minimum Vegan Rating: {filters.veganRatingMin || 0}</Typography><Slider min={0} max={5} step={.5} value={Number(filters.veganRatingMin || 0)} onChange={(_, v) => set('veganRatingMin', v)} /></Grid>
      <Grid item xs={12}><FormControlLabel control={<Checkbox checked={Boolean(filters.availableOnly)} onChange={(e) => set('availableOnly', e.target.checked)} />} label="Available only" /></Grid>
      {kind === 'liveaboard' ? <Grid item xs={12}>
        {['specialOffer','nitrox','photography','rebreather'].map((key) => <FormControlLabel key={key} control={<Checkbox checked={Boolean(filters[key])} onChange={(e) => set(key, e.target.checked)} />} label={{specialOffer:'Special offers',nitrox:'Nitrox',photography:'Photography',rebreather:'Rebreather'}[key]} />)}
      </Grid> : null}
    </Grid>
    {[['dietary','Dietary',dietary],['accessibility','Accessibility',accessibility],['facilities','Facilities',facilities]].map(([key,label,options]) => options.length ? <Accordion key={key} disableGutters elevation={0}>
      <AccordionSummary><Typography fontWeight={600}>{label}</Typography></AccordionSummary>
      <AccordionDetails>{options.map((opt) => { const value = opt.slug || opt.code || opt.value || opt.name; const text = opt.label || opt.name || value; const selected = comma(filters[key]).includes(value); return <FormControlLabel key={value} control={<Checkbox checked={selected} onChange={() => set(key, toggle(comma(filters[key]), value))} />} label={text} />; })}</AccordionDetails>
    </Accordion> : null)}
    <Button onClick={onClear} sx={{ mt: 2 }}>Clear filters</Button>
  </Box>;
}
