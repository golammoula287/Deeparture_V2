import React, { useState } from 'react';
import { Box, Stack } from '@mui/material';
import { pickImages } from '../../../lib/customerView';
export default function ImageGallery({ item, aspect = '16/9' }) {
  const images = pickImages(item);
  const [active, setActive] = useState(0);
  if (!images.length) return <Box sx={{ aspectRatio: aspect, bgcolor: 'grey.100', borderRadius: 2 }} />;
  return <Box>
    <Box component="img" src={images[active]?.url} alt={images[active]?.alt || ''} loading="eager" sx={{ width: '100%', aspectRatio: aspect, objectFit: 'cover', borderRadius: 2, display: 'block' }} />
    {images.length > 1 ? <Stack direction="row" spacing={1} sx={{ mt: 1, overflowX: 'auto', pb: .5 }}>
      {images.slice(0, 10).map((img, i) => <Box component="button" key={`${img.url}-${i}`} onClick={() => setActive(i)} aria-label={`Show image ${i+1}`} sx={{ border: i === active ? 2 : 1, borderColor: i === active ? 'primary.main' : 'divider', p: 0, borderRadius: 1, overflow: 'hidden', flex: '0 0 84px', bgcolor: 'transparent' }}><Box component="img" src={img.url} alt="" loading="lazy" sx={{ width: 84, height: 56, objectFit: 'cover', display: 'block' }} /></Box>)}
    </Stack> : null}
  </Box>;
}
