import CustomerSearchPage from '../../../components/v2/customer/CustomerSearchPage';
export default function LiveaboardSearch(){return <CustomerSearchPage kind="liveaboard"/>;}
