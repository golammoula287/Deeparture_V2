import CustomerSearchPage from '../../../components/v2/customer/CustomerSearchPage';
export default function ResortSearch(){return <CustomerSearchPage kind="resort"/>;}
