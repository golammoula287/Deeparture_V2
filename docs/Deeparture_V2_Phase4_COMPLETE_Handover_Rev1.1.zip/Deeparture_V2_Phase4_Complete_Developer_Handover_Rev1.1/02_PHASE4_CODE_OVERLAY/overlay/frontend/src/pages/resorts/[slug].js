import CustomerDetailPage from '../../components/v2/customer/CustomerDetailPage';
import { getResort } from '../../api/customerApi';
export default function ResortPage({ item }) { return <CustomerDetailPage item={item} kind="resort"/>; }
export async function getServerSideProps({ params, res }) {
  try { const item=await getResort(params.slug); res.setHeader('Cache-Control','public, s-maxage=60, stale-while-revalidate=120'); return { props:{ item } }; }
  catch(error){ if(error?.status===404) return {notFound:true}; throw error; }
}
