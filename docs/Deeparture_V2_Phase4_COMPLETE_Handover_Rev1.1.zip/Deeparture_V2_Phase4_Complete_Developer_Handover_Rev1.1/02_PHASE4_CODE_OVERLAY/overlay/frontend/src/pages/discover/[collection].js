import React from 'react';
import Head from 'next/head';
import { Container, Typography } from '@mui/material';
import SearchResults from '../../components/v2/customer/SearchResults';
import { searchLiveaboards } from '../../api/customerApi';
const COLLECTIONS={
  'vegan-liveaboards':{title:'Vegan-friendly liveaboards',description:'Discover liveaboards with structured vegan information.',query:{veganRatingMin:3,sort:'veganRating'}},
  'last-minute-liveaboards':{title:'Last-minute liveaboard offers',description:'Current liveaboard departures with active offers.',query:{specialOffer:true,availableOnly:true,sort:'startDate'}},
  'free-nitrox-liveaboards':{title:'Liveaboards with nitrox',description:'Discover liveaboards with nitrox facilities.',query:{nitrox:true,sort:'startDate'}},
  'photography-liveaboards':{title:'Photography-friendly liveaboards',description:'Find liveaboards with photography-focused facilities or attributes.',query:{photography:true,sort:'startDate'}},
};
export default function Collection({collection,data}){return <><Head><title>{collection.title} | Deeparture</title><meta name="description" content={collection.description}/><link rel="canonical" href={`https://deeparture.travel/discover/${collection.slug}`}/></Head><Container maxWidth="xl" sx={{py:5}}><Typography variant="h2" component="h1" gutterBottom>{collection.title}</Typography><Typography color="text.secondary" sx={{mb:4}}>{collection.description}</Typography><SearchResults data={data} kind="liveaboard"/></Container></>}
export async function getServerSideProps({params,res}){const c=COLLECTIONS[params.collection];if(!c)return{notFound:true};const data=await searchLiveaboards({...c.query,page:1,pageSize:24});res.setHeader('Cache-Control','public, s-maxage=300, stale-while-revalidate=600');return{props:{collection:{...c,slug:params.collection},data}};}
