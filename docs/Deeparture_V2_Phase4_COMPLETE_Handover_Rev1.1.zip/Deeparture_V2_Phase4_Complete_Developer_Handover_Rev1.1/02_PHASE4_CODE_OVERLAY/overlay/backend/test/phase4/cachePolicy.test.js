'use strict'; const test=require('node:test'); const assert=require('node:assert/strict'); const {isFreshnessSensitive,publicCacheControl}=require('../../src/v2/phase4/cachePolicy');
test('commercial endpoints are freshness-sensitive',()=>{for(const p of ['/availability','/prices','/offers','/departures','/enquiries'])assert.equal(isFreshnessSensitive(p),true);});
test('catalogue shell may use short CDN cache',()=>{assert.match(publicCacheControl({path:'/liveaboards'}),/^public,/);});
test('commercial data is never cached by helper',()=>{assert.equal(publicCacheControl({path:'/liveaboards',hasCommercialData:true}),'no-store');});
