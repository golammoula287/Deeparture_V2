'use strict';
const test=require('node:test'); const assert=require('node:assert/strict');
const {normalizeLiveaboardQuery,normalizeResortQuery,MAX_PAGE_SIZE,toPage}=require('../../src/v2/phase4/publicQuery');
test('liveaboard query normalizes compound filters',()=>{const q=normalizeLiveaboardQuery({destination:'raja-ampat',startFrom:'2027-02-01',startTo:'2027-03-01',minNights:'7',maxNights:'12',minPrice:'3000',maxPrice:'7000',veganRatingMin:'4',specialOffer:'true',availableOnly:'1',facilities:['wifi','camera-room'],page:'2',pageSize:'24',sort:'startDate'});assert.equal(q.destination,'raja-ampat');assert.equal(q.startFrom,'2027-02-01');assert.equal(q.minNights,7);assert.equal(q.maxPrice,7000);assert.equal(q.specialOffer,true);assert.equal(q.availableOnly,true);assert.deepEqual(q.facilities,['wifi','camera-room']);assert.equal(q.skip,24);});
test('page size is capped',()=>{assert.equal(normalizeLiveaboardQuery({pageSize:999}).pageSize,MAX_PAGE_SIZE);});
test('invalid sort falls back to allowlisted default',()=>{assert.equal(normalizeLiveaboardQuery({sort:'$where'}).sort,'startDate');assert.equal(normalizeResortQuery({sort:'dropTable'}).sort,'name');});
test('bad dates do not leak into service query',()=>{assert.equal(normalizeLiveaboardQuery({startFrom:'tomorrow'}).startFrom,undefined);});
test('list supports repeated and comma-separated parameters',()=>{assert.deepEqual(normalizeLiveaboardQuery({dietary:['vegan,gluten-free','nut-free']}).dietary,['vegan','gluten-free','nut-free']);});
test('page envelope is deterministic',()=>{assert.deepEqual(toPage([{id:1}],49,{page:2,pageSize:24,sort:'startDate'}),{items:[{id:1}],page:2,pageSize:24,total:49,totalPages:3,sort:'startDate'});});
