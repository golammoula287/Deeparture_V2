'use strict';
const DEFAULT_PAGE_SIZE=24, MAX_PAGE_SIZE=60;
const LIVEABOARD_SORTS=new Set(['startDate','priceAsc','priceDesc','veganRating','name']);
const RESORT_SORTS=new Set(['name','priceAsc','priceDesc','veganRating']);
function first(v){return Array.isArray(v)?v[0]:v;}
function int(v,d,{min=1,max=Number.MAX_SAFE_INTEGER}={}){const n=Number.parseInt(first(v),10);if(!Number.isFinite(n))return d;return Math.min(max,Math.max(min,n));}
function num(v){if(v===undefined||v===null||v==='')return undefined;const n=Number(first(v));return Number.isFinite(n)?n:undefined;}
function bool(v){if(v===undefined||v===null||v==='')return undefined;const x=String(first(v)).toLowerCase();if(['true','1','yes'].includes(x))return true;if(['false','0','no'].includes(x))return false;return undefined;}
function list(v){if(v===undefined||v===null||v==='')return [];return (Array.isArray(v)?v:[v]).flatMap((x)=>String(x).split(',')).map((x)=>x.trim()).filter(Boolean).slice(0,50);}
function date(v){if(!v)return undefined;const s=String(first(v));return /^\d{4}-\d{2}-\d{2}$/.test(s)?s:undefined;}
function text(v,max=120){if(v===undefined||v===null)return undefined;const s=String(first(v)).trim();return s?s.slice(0,max):undefined;}
function common(q,sorts,defaultSort){
  const page=int(q.page,1,{min:1,max:100000}); const pageSize=int(q.pageSize,DEFAULT_PAGE_SIZE,{min:1,max:MAX_PAGE_SIZE});
  const requested=text(q.sort,40); const sort=sorts.has(requested)?requested:defaultSort;
  return { page,pageSize,skip:(page-1)*pageSize,sort,destination:text(q.destination),minPrice:num(q.minPrice),maxPrice:num(q.maxPrice),veganRatingMin:num(q.veganRatingMin),dietary:list(q.dietary),accessibility:list(q.accessibility),facilities:list(q.facilities),availableOnly:bool(q.availableOnly) };
}
function normalizeLiveaboardQuery(q={}){return {...common(q,LIVEABOARD_SORTS,'startDate'),startFrom:date(q.startFrom||q.startDate),startTo:date(q.startTo||q.endDate),embarkation:text(q.embarkation),minNights:num(q.minNights),maxNights:num(q.maxNights),nitrox:bool(q.nitrox),photography:bool(q.photography),rebreather:bool(q.rebreather),specialOffer:bool(q.specialOffer)};}
function normalizeResortQuery(q={}){return common(q,RESORT_SORTS,'name');}
function toPage(items,total,q){const t=Number(total||0);return{items,page:q.page,pageSize:q.pageSize,total:t,totalPages:Math.max(1,Math.ceil(t/q.pageSize)),sort:q.sort};}
module.exports={DEFAULT_PAGE_SIZE,MAX_PAGE_SIZE,LIVEABOARD_SORTS,RESORT_SORTS,normalizeLiveaboardQuery,normalizeResortQuery,toPage,_private:{int,num,bool,list,date,text}};
