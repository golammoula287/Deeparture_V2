'use strict';
const express=require('express');
const { normalizeLiveaboardQuery, normalizeResortQuery }=require('./publicQuery');
function required(fn,name){if(typeof fn!=='function')throw new TypeError(`Phase 4 adapter requires ${name}`);return fn;}
function createPhase4PublicRouter(deps={}){
  const searchLiveaboards=required(deps.searchLiveaboards,'searchLiveaboards');
  const getLiveaboard=required(deps.getLiveaboard,'getLiveaboard');
  const searchResorts=required(deps.searchResorts,'searchResorts');
  const getResort=required(deps.getResort,'getResort');
  const submitEnquiry=required(deps.submitEnquiry,'submitEnquiry');
  const searchDepartures=deps.searchDepartures;
  const router=express.Router();
  const wrap=(fn)=>(req,res,next)=>Promise.resolve(fn(req,res)).catch(next);
  router.get('/liveaboards',wrap(async(req,res)=>res.json(await searchLiveaboards(normalizeLiveaboardQuery(req.query),{req}))));
  router.get('/liveaboards/:slug',wrap(async(req,res)=>{const item=await getLiveaboard(req.params.slug,{req});if(!item)return res.status(404).json({code:'NOT_FOUND',message:'Liveaboard not found'});res.json(item);}));
  router.get('/resorts',wrap(async(req,res)=>res.json(await searchResorts(normalizeResortQuery(req.query),{req}))));
  router.get('/resorts/:slug',wrap(async(req,res)=>{const item=await getResort(req.params.slug,{req});if(!item)return res.status(404).json({code:'NOT_FOUND',message:'Resort not found'});res.json(item);}));
  if(typeof searchDepartures==='function') router.get('/departures',wrap(async(req,res)=>res.json(await searchDepartures(normalizeLiveaboardQuery(req.query),{req}))));
  router.post('/enquiries',express.json({limit:'100kb'}),wrap(async(req,res)=>{const body=req.body||{};if(!body.fullName||!body.email||!body.message)return res.status(400).json({code:'VALIDATION_ERROR',message:'Name, email and message are required'});const result=await submitEnquiry(body,{req});res.status(201).json(result);}));
  return router;
}
module.exports={createPhase4PublicRouter};
