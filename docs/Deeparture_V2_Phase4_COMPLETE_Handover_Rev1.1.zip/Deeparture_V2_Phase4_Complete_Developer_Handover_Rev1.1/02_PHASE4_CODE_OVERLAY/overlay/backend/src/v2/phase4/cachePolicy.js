'use strict';
function isFreshnessSensitive(path=''){
  const p=String(path).toLowerCase();
  return p.includes('availability')||p.includes('price')||p.includes('offer')||p.includes('departure')||p.includes('enquir');
}
function publicCacheControl({path='',hasCommercialData=false}={}){
  if(hasCommercialData||isFreshnessSensitive(path)) return 'no-store';
  return 'public, max-age=0, s-maxage=60, stale-while-revalidate=120';
}
module.exports={isFreshnessSensitive,publicCacheControl};
