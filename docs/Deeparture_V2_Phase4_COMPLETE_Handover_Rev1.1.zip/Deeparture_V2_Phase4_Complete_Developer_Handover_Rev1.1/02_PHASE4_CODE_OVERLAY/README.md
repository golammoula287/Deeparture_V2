# Deeparture V2 — Phase 4 Code Overlay Rev 1.0

Target baseline: accepted Phase 3 commit `f6693c6a05b7bd172fc773fe010494ee61f276f9`.

This package implements the Phase 4 customer frontend + PWA as a **non-destructive overlay**. It is intentionally not presented as a fully merged replacement repository because the accepted Phase 3 ZIP is visible in the project library but its raw bytes were not mountable in the build environment used to prepare this package.

## What is included

- Centralized customer V2 API client and query-state helpers.
- Liveaboard and resort search pages.
- Reusable mobile-first filter panel, cards, pricing, offer, availability, gallery and enquiry components.
- Liveaboard/resort detail-page implementations.
- Departure table with mobile card transformation.
- SEO helpers and curated discovery-page pattern.
- Conservative PWA manifest/service worker and install registration.
- Backend Phase 4 public-query contract helpers for server-side pagination/sorting/filter validation.
- Integration adapter contract so accepted Phase 3 services remain the source of truth.
- Node built-in unit tests for search-query parsing, pagination, sort allowlists and freshness-safe cache rules.
- API contract examples and integration instructions.

## Critical integration rule

Do **not** copy business rules into React. Wire the backend adapter to the accepted Phase 3 search/pricing/availability/enquiry services. If an existing service already implements a feature, use it directly rather than duplicating it.

## Install order

1. Checkout accepted Phase 3 commit `f6693c6a05b7bd172fc773fe010494ee61f276f9`.
2. Create a Phase 4 branch.
3. Copy the contents of `overlay/` into the repository root, preserving paths.
4. Follow `INTEGRATION.md` for the few deliberate wiring steps that cannot safely be automated without the exact Phase 3 source tree.
5. Run `node --test backend/test/phase4/*.test.js`.
6. Run the existing Phase 1–3 backend regression suite.
7. Build the frontend and deploy to staging.
8. Complete the Phase 4 acceptance checklist against the hosted build.

## Scope caveat

The code is designed for the documented Phase 3 API architecture (`/api/v2/liveaboards`, `/api/v2/resorts`, `/api/v2/departures`, `/api/v2/enquiries`, `/api/v2/attributes`) and the established Next.js 14 Pages Router / React 18 frontend. Exact imports/mount locations for accepted Phase 3 internal services must be reconciled during application of the overlay; this package does not invent replacement Phase 3 models.
