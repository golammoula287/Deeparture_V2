# Source baseline note

Accepted Phase 3 baseline:

`f6693c6a05b7bd172fc773fe010494ee61f276f9`

The final `phase3.zip` is retained in the Deeparture project Library, but its raw bytes were not authorized for materialization into the code-generation container during this work. To avoid silently rebuilding on an older Phase 2B snapshot or inventing accepted Phase 3 internals, Phase 4 has been implemented as a non-destructive overlay against the documented Phase 3 public/API architecture.

This means:
- no accepted Phase 3 models are replaced;
- no older source is substituted for the accepted baseline;
- backend Phase 4 routing uses dependency injection into the existing Phase 3 services;
- frontend code consumes the established versioned `/api/v2/...` contracts through one centralized client;
- exact service import/mount locations must be reconciled when the overlay is applied to the accepted Git checkout.
