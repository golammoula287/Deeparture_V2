# File-by-file Phase 4 overlay summary

## Frontend
- `src/api/v2Client.js` — centralized HTTP/error/paged-response layer.
- `src/api/customerApi.js` — all customer V2 endpoints in one module.
- `src/lib/searchState.js` — URL/query state normalization and faceted indexation detection.
- `src/lib/customerView.js` — presentation-only compatibility selectors; no business-rule calculations.
- `src/components/v2/customer/*` — reusable search/detail/pricing/availability/enquiry UI.
- `src/pages/explore/liveaboards/index.js` — liveaboard customer search.
- `src/pages/explore/resorts/index.js` — resort customer search.
- `src/pages/liveaboards/[slug].js` — liveaboard detail page.
- `src/pages/resorts/[slug].js` — resort detail page.
- `src/pages/discover/[collection].js` — curated SEO collection pattern using same API.
- `src/components/v2/pwa/PwaRegistrar.jsx` — production service-worker registration.
- `public/manifest.webmanifest` and `public/sw.js` — installable PWA with conservative commercial-data caching policy.

## Backend
- `src/v2/phase4/publicQuery.js` — strict public-query normalization, pagination and sort allowlists.
- `src/v2/phase4/cachePolicy.js` — explicit freshness-sensitive caching rules.
- `src/v2/phase4/publicRouterFactory.js` — dependency-injected router contract for accepted Phase 3 services.
- `test/phase4/*.test.js` — dependency-free unit tests.

No Phase 1–3 model is replaced by this overlay.
