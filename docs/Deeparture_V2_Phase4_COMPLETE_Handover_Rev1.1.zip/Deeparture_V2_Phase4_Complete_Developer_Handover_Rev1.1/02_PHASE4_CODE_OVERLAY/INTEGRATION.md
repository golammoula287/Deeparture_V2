# Phase 4 integration guide

## 1. Start from the accepted baseline

Use commit:

`f6693c6a05b7bd172fc773fe010494ee61f276f9`

Do not start from an older Phase 2B or standalone branch.

## 2. Frontend overlay

Copy `overlay/frontend/` into the existing frontend root.

The implementation assumes the existing project uses `frontend/src/pages` and `frontend/src/components`, which matches the original source audit. If the accepted Phase 3 branch moved the Pages Router root, keep the same modules but place them in that current root.

The customer pages call only the centralized modules under `src/api/`.

### Required environment variable

`NEXT_PUBLIC_API_URL` should be the backend `/api` base, for example:

`https://example-api.onrender.com/api`

The client then requests `/v2/...` beneath that base.

## 3. Existing routes

The overlay replaces/enhances the documented automatic public routes:

- `/explore/liveaboards`
- `/explore/resorts`
- `/liveaboards/[slug]`
- `/resorts/[slug]`

It also adds a curated collection pattern:

- `/discover/[collection]`

Do not remove legacy redirects that the accepted branch already preserves.

## 4. PWA registration

Add `<PwaRegistrar />` once in the existing `pages/_app` component, after the app mounts. Import:

```js
import PwaRegistrar from '@/components/v2/pwa/PwaRegistrar';
```

Then render it alongside the page component:

```jsx
<>
  <Component {...pageProps} />
  <PwaRegistrar />
</>
```

If the repository does not have the `@/` alias, use the corresponding relative import.

The provided `public/sw.js` deliberately does **not** cache `/api/`, enquiries, pricing or availability responses.

## 5. Backend query contract

Copy `overlay/backend/src/v2/phase4/` and `overlay/backend/test/phase4/` into the backend.

`publicQuery.js` is a dependency-free helper that provides:

- strict pagination caps
- sort allowlists
- date/number/boolean normalization
- safe array-list parsing
- public filter normalization

`publicRouterFactory.js` is an Express router factory. Wire it to the accepted Phase 3 services rather than importing Mongoose models directly.

Example:

```js
const { createPhase4PublicRouter } = require('./v2/phase4/publicRouterFactory');
const liveaboardService = require('./existing/v2/liveaboard.service');
const resortService = require('./existing/v2/resort.service');
const departureService = require('./existing/v2/departure.service');
const enquiryService = require('./existing/v2/enquiry.service');

app.use('/api/v2/customer', createPhase4PublicRouter({
  searchLiveaboards: liveaboardService.searchPublic,
  getLiveaboard: liveaboardService.getPublicBySlug,
  searchResorts: resortService.searchPublic,
  getResort: resortService.getPublicBySlug,
  searchDepartures: departureService.searchPublic,
  submitEnquiry: enquiryService.createPublic,
}));
```

If the accepted Phase 3 routes already expose equivalent functionality at `/api/v2/liveaboards`, `/api/v2/resorts`, `/api/v2/departures` and `/api/v2/enquiries`, **prefer extending those existing controllers with the normalized query helper** instead of mounting duplicate customer routes.

## 6. Backend service expectations

The public service functions should return resolved values rather than asking the frontend to calculate them. Search responses should expose, when applicable:

```json
{
  "items": [],
  "page": 1,
  "pageSize": 24,
  "total": 0,
  "totalPages": 0,
  "sort": "startDate"
}
```

Liveaboard/departure items should expose the already-resolved customer price and availability state. Suggested shape:

```json
{
  "effectivePrice": {
    "amount": 2797,
    "currency": "USD",
    "rackAmount": 3995,
    "hasOffer": true,
    "offerLabel": "30% off"
  },
  "availability": {
    "status": "available",
    "availableUnits": 4,
    "updatedAt": "2026-11-02T00:00:00Z",
    "freshness": "current"
  }
}
```

Do not calculate offer expiry, rack/sale hierarchy or sellable availability in React.

## 7. Phase 4 API changes to reconcile on the accepted branch

The accepted backend should support these public query concepts. Naming may follow existing service conventions, but semantics should remain stable:

### Liveaboards
- destination
- startFrom / startTo
- embarkation
- minPrice / maxPrice
- minNights / maxNights
- veganRatingMin
- dietary[]
- accessibility[]
- facilities[]
- nitrox
- photography
- rebreather
- availableOnly
- specialOffer
- page / pageSize
- sort

### Resorts
- destination
- minPrice / maxPrice
- veganRatingMin
- dietary[]
- accessibility[]
- facilities[]
- availableOnly
- page / pageSize
- sort

## 8. SEO/indexation

Interactive faceted search pages should not automatically become indexable landing pages. The provided search pages emit `noindex,follow` when filter query parameters are present. Curated `/discover/[collection]` pages can be indexable and use the same shared search API.

## 9. Media

The overlay consumes image URLs/media references. Do not add base64 image persistence to support these components.

## 10. Validation after merge

Run:

```bash
node --test backend/test/phase4/*.test.js
npm test                # existing backend suite, if this is the project command
npm run build           # frontend production build
```

Then verify mobile, tablet and desktop on staging and complete the Phase 4 acceptance checklist.
