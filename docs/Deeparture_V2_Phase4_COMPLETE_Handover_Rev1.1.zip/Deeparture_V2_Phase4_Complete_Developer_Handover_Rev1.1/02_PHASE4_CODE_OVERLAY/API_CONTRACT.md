# Phase 4 customer API contract

This document describes frontend expectations. Existing accepted Phase 3 service names may differ; preserve the semantics.

## GET /api/v2/liveaboards

Supported query: destination, startFrom, startTo, embarkation, minPrice, maxPrice, minNights, maxNights, veganRatingMin, dietary, accessibility, facilities, nitrox, photography, rebreather, availableOnly, specialOffer, page, pageSize, sort.

Response should be a paged envelope (`items`, `page`, `pageSize`, `total`, `totalPages`) or an existing equivalent that the centralized client can normalize.

## GET /api/v2/resorts

Supported query: destination, minPrice, maxPrice, veganRatingMin, dietary, accessibility, facilities, availableOnly, page, pageSize, sort.

## GET /api/v2/liveaboards/:slug

Return a public-safe customer representation. If departures are embedded in the response, each should expose resolved pricing/offer/availability rather than raw records that require React to reproduce business rules.

## GET /api/v2/resorts/:slug

Return a public-safe customer representation with room/package/rate/availability context when available.

## POST /api/v2/enquiries

Example:

```json
{
  "fullName": "Customer Name",
  "email": "customer@example.com",
  "message": "I am interested in this trip.",
  "context": {
    "kind": "liveaboard",
    "listingId": "...",
    "slug": "damai-i",
    "departureId": "..."
  }
}
```

The backend must validate/sanitize input and preserve context through the existing admin/operator enquiry workflow.
