# DEEPARTURE V2 — PHASE 4 COMPLETE DEVELOPER HANDOVER

## READ THIS FIRST

This package contains the complete Phase 4 handover: the previously supplied **Phase 4 Rev 1.1 specification / acceptance package** plus the **Phase 4 code overlay**.

### Critical baseline instruction

**The Phase 4 code is an overlay, NOT a replacement repository.**

Apply / merge the code overlay onto the accepted Phase 3 baseline commit:

`f6693c6a05b7bd172fc773fe010494ee61f276f9`

Do **not** replace, revert, or rebuild from an older Phase 1 / Phase 2 / Phase 2B source archive.
Do **not** remove accepted Phase 3 functionality unless the Phase 4 specification explicitly requires a documented change.

The accepted Phase 3 baseline remains the source of truth for:
- authentication and organisation membership
- role / permission behaviour
- operator portal functionality
- catalogue ownership
- pricing / availability / offer domain services
- enquiry / notification foundations
- existing Phase 1–3 V2 APIs and data contracts

Phase 4 adds the customer-facing experience and required search/PWA functionality on top of that baseline.

---

## Package structure

### `01_PHASE4_SPECIFICATION_AND_ACCEPTANCE/`
This is the full Phase 4 Rev 1.1 package previously supplied.
It contains:
- Phase 4 Developer Specification
- Phase 4 Acceptance Checklist
- Future-Proofing Compliance Matrix
- Developer Return Requirements
- Phase 4 README / manifest

The Rev 1.1 documents are the controlling Phase 4 scope and acceptance requirements.

### `02_PHASE4_CODE_OVERLAY/`
This contains the Phase 4 code delta and integration documentation.

**Start with `02_PHASE4_CODE_OVERLAY/INTEGRATION.md`.**

The overlay includes:
- customer-facing liveaboard search
- customer-facing resort search
- reusable result/detail components
- filters and mobile filter drawer
- itinerary and departure presentation
- resolved price / offer / availability presentation
- enquiry flow
- curated discovery / SEO page support
- PWA manifest, service worker and offline fallback
- centralized V2 frontend API client/data layer
- backend Phase 4 public query normalization, pagination/sorting helpers and cache policy
- unit tests and test evidence

### `03_ORIGINAL_ZIPS/`
Contains exact copies of the two source packages used to create this combined handover:
- `Deeparture_Phase4_Rev1.1.zip`
- `Deeparture_V2_Phase4_Code_Overlay_Rev1.0.zip`

These are included for provenance/reference. The extracted folders above are easier to work from.

---

## Required developer workflow

1. Confirm the working branch starts from accepted Phase 3 commit:
   `f6693c6a05b7bd172fc773fe010494ee61f276f9`
2. Read the Rev 1.1 Developer Specification and Future-Proofing Compliance Matrix.
3. Read `02_PHASE4_CODE_OVERLAY/INTEGRATION.md` before copying or merging files.
4. Apply the Phase 4 overlay to the accepted Phase 3 repository.
5. Wire the overlay only to the existing Phase 3 V2 services / contracts; do not create a parallel customer business-logic architecture.
6. Resolve any path differences against the actual accepted Phase 3 repository rather than replacing Phase 3 files wholesale.
7. Run all existing Phase 1–3 regression tests.
8. Run the Phase 4 tests included in the overlay and add/adjust integration tests as needed after merge.
9. Build the frontend production bundle and backend successfully.
10. Deploy to staging only.
11. Complete the Phase 4 Acceptance Checklist against staging.
12. Return the required evidence package, including exact branch + full commit hash, staging URLs, test/build output and completed checklist.

---

## Non-negotiable future-proofing rules

Phase 4 must preserve:
- one shared V2 source of truth for catalogue, pricing, offers, availability and taxonomy
- versioned V2 APIs
- centralized frontend API/data access
- reusable/config-driven customer components
- server-side filtering, pagination and deterministic sorting
- stable public slugs / identifiers
- curated SEO rather than uncontrolled faceted indexation
- normalized availability freshness/source semantics
- compatibility with later operator APIs / feeds / webhooks
- compatibility with later native and agent clients
- media/CDN-ready references; do not add new base64-in-database image storage
- staging-first, backward-compatible development
- source-controlled, reproducible changes

Later-phase functionality such as external operator feeds, automated ingestion, native apps, the agent platform and production cutover is **not part of Phase 4** unless separately approved.

---

## Acceptance boundary

Phase 4 is **not complete simply because the pages render**.
It must pass the Rev 1.1 checklist, future-proofing requirements, regression checks, production build and staging verification.

No production cutover is authorised by this package.
