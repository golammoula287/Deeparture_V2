# Deeparture V2 - Phase 4 Customer Frontend V2 + PWA

## Developer package

Prepared: 2 November 2026

Accepted Phase 3 baseline:
`f6693c6a05b7bd172fc773fe010494ee61f276f9`

## Start here

Phase 4 must be developed from the accepted Phase 3 baseline above. Do not begin from an earlier standalone/legacy branch.

The package contains:

1. `Deeparture_V2_Phase4_Developer_Specification.pdf` - authoritative Phase 4 scope and architecture rules.
2. `Deeparture_V2_Phase4_Developer_Specification.docx` - editable reference copy.
3. `Deeparture_V2_Phase4_Acceptance_Checklist.pdf` - acceptance checklist to be completed and returned.
4. `Deeparture_V2_Phase4_Acceptance_Checklist.docx` - editable checklist copy.
5. `PHASE4_DEVELOPER_RETURN_REQUIREMENTS.md` - exact handback package required for audit/sign-off.

## Phase 4 objective

Build the complete customer-facing V2 search/discovery experience for liveaboards and resorts, including responsive detail pages, effective pricing/offers/availability, enquiry flow, curated SEO-ready discovery, mobile-first UX and an installable PWA.

## Architectural rule

The frontend must consume the same shared V2 catalogue, search, pricing, availability, offer and enquiry services already established in Phases 1-3. Do not create parallel customer-only business logic or direct database access from the browser.

## Explicitly deferred

- Native iOS/Android apps
- External operator APIs / live webhook integrations
- Automated website scraping and scheduled source re-checks
- Agent/B2B platform
- Dynamic packaging
- Production V1 cutover/retirement unless separately authorised

## Acceptance

The developer returns the completed checklist plus the evidence package described in `PHASE4_DEVELOPER_RETURN_REQUIREMENTS.md`. Phase 4 is not accepted merely because the UI looks complete; the tested commit, hosted build, backend business rules, mobile flows, SEO handling and PWA behaviour must all be reproducible.


---

## Mandatory future-proofing checks (Rev 1.1)

Phase 4 must also comply with the original Deeparture V2 architecture/future-proofing documents:

- centralized frontend API/data layer rather than scattered component-level business fetch logic
- reusable customer components and configuration-driven filter/taxonomy presentation
- server-side filtering, pagination and deterministic sorting
- versioned V2 API contracts reusable by web, PWA and later clients
- no parallel customer-only pricing, availability, offers or taxonomy architecture
- no new base64-in-database media path; preserve object-storage/CDN-ready media references
- stable public slugs/identifiers and controlled SEO/faceted URL handling
- normalized service boundaries preserved for future operator APIs, feeds and webhooks
- no production/V1 destructive cutover in Phase 4
- freshness-safe PWA caching for commercial data

The detailed compliance mapping is in `Deeparture_V2_Phase4_Future_Proofing_Compliance_Matrix.pdf`.
