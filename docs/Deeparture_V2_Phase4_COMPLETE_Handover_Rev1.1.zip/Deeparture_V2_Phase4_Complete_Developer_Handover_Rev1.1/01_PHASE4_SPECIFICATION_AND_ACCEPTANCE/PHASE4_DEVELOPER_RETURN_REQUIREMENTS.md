# Phase 4 Developer Return Requirements

Return one ZIP after implementation containing the following.

## 1. Source identity
- Git branch name
- Full commit hash
- Confirmation that development started from accepted Phase 3 commit `f6693c6a05b7bd172fc773fe010494ee61f276f9`
- Pull request / patch or concise file-by-file change summary

## 2. Hosted environment
- Frontend staging URL
- Backend/API staging URL
- Any PWA-specific test/install URL if different
- Staging database/environment identifier (no credentials)
- Deployment revision mapped to the returned commit

## 3. Completed acceptance checklist
Return `Deeparture_V2_Phase4_Acceptance_Checklist` with Local and Render/Staging status completed. Every PASS must have enough evidence to reproduce or inspect the result.

## 4. Automated evidence
- Exact test commands
- Test result output/log or machine-readable result file
- Production build command/result
- Existing Phase 1-3 regression result
- New Phase 4 tests added

## 5. API / architecture evidence
For every changed/added endpoint or search query:
- endpoint and method
- query parameters / payload examples
- sample success/error response
- service/module that owns the business rule

Confirm that core filtering, pricing, offers and availability are not implemented only as frontend post-processing.

## 6. Visual / browser evidence
Provide evidence for representative:
- desktop liveaboard search/detail/enquiry
- phone liveaboard search/detail/enquiry
- desktop resort search/detail/enquiry
- phone resort search/detail/enquiry
- mobile filter panel/drawer
- departure table -> mobile card/stack transformation
- installed PWA launch

## 7. SEO evidence
Provide representative page source or browser evidence for:
- title/description
- canonical URL
- indexability/noindex handling
- curated landing page using shared taxonomy/search data
- faceted URLs not creating uncontrolled indexable thin pages

## 8. PWA evidence
- manifest validation
- service-worker/runtime registration
- installability result
- installed launch result
- offline/interrupted-network behaviour
- documented caching strategy for freshness-sensitive pricing/offers/availability

## 9. Deployment/configuration
- environment-variable changes by name only (never secret values)
- dependency changes
- deployment notes
- migration/dry-run/backup/rollback instructions if any database migration was necessary

## 10. Known issues and exclusions
List every remaining known issue, workaround, deferred item or test limitation. Do not mark blocked or unevidenced requirements as PASS.

## Phase 4 acceptance rule
Infinite Blue will audit the returned package against the checklist. Formal Phase 4 sign-off is separate from developer completion and is required before the project proceeds to the next phase.


## 10. Future-proofing architecture evidence (Rev 1.1)
Return:
- centralized frontend API/data-layer module(s) and representative usage
- reusable customer component/module list
- shared filter/taxonomy configuration location or explanation
- server-side pagination and deterministic sorting examples
- media/image path and confirmation no new base64-in-database path was introduced
- short note explaining how future operator feeds/native clients/agent tools can consume the same V2 service/API contracts without duplicating customer business logic
