# Deeparture V2 - Phase 2B Developer README
## Admin Automation & Management Enhancements

**Revision 1.1 - Adds availability source management, freshness/staleness, history, overrides, conflict handling, and connector-ready configuration.**

Phase 2B builds on a working Phase 2A Admin V2.

Do not begin Phase 2B until the core catalogue/import/claim workflow from Phase 2A is stable.

---

# 1. Objective

Add the advanced admin capabilities that improve scale, traceability, automation readiness, and day-to-day management.

Phase 2B should improve the system without changing the core business flow already proven in 2A.

---

# 2. Phase 2B Scope

Main additions:

- richer import history
- advanced import error reporting
- advanced duplicate reconciliation
- in-app notification centre
- richer audit log
- source/provenance management
- operator verification controls
- claim invitation history
- listing completeness indicators
- advanced organisation activity
- website source queue
- better admin dashboard metrics
- admin bulk actions
- advanced filtering
- better operational reporting
- availability source/freshness management
- stale-availability warnings
- availability update history
- manual availability overrides
- multi-source conflict/priority handling
- connector-ready availability source configuration

---

# 3. Implementation Steps

## Step 1 - Advanced Import History
Build:

```text
/admin/v2/imports/history
```

Each batch shows:
- timestamp
- admin user
- source/filename
- import type
- row total
- created
- updated
- skipped
- duplicates
- errors
- status
- affected records

Suggested statuses:

```text
uploaded
validated
awaiting_confirmation
processing
completed
completed_with_errors
failed
cancelled
```

## Step 2 - Import Error Reports
Allow admin to:
- open row-level errors
- filter by error type
- download error report
- open affected source record
- retry corrected rows where practical

## Step 3 - Duplicate Reconciliation Workspace
Create a review UI for ambiguous matches.

Admin can:
- compare incoming operator/listing vs existing record
- choose match existing
- choose create new
- merge selected fields where appropriate
- mark as not duplicate

Never auto-merge ambiguous data.

## Step 4 - In-App Notification Centre
Create Notification model/UI.

Examples:
- new listing submitted
- claim completed
- import completed
- import failed
- enquiry received
- operator accepted enquiry
- listing needs review

Fields:

```text
type
title
message
relatedRecordType
relatedRecordId
readAt
createdAt
```

Admin header should show unread count.

## Step 5 - Advanced Audit Log
Build searchable audit UI:

```text
/admin/v2/audit
```

Track:
- publish/unpublish
- restrict/reactivate
- claim invitation
- claim completion
- import commit
- attribute changes
- destination/port changes
- enquiry status changes
- organisation changes

Audit fields:

```text
actorUserId
actorOrganisationId
action
entityType
entityId
before
after
metadata
createdAt
```

Never store passwords/tokens/secrets in audit payloads.

## Step 6 - Provenance / Source Management
Add richer listing-level source tracking.

At minimum:

```text
sourceType
sourceUrl
sourceName
lastCheckedAt
operatorVerified
operatorVerifiedAt
deepartureVerified
deepartureVerifiedAt
```

Suggested source types:

```text
deeparture_import
admin_manual
operator
operator_website
csv
xlsx
api
legacy_migration
```

Field-level provenance can be prepared for later but is not mandatory if it adds excessive complexity.

## Step 7 - Verification Controls
Admin can:
- mark organisation verified
- mark listing Deeparture verified
- see operator verified state
- see last verification date
- remove verification if information becomes stale

Verification should not be the same as publication state.

## Step 8 - Claim Invitation Management
Add:
- invitation history
- sent date
- expiry
- resend
- revoke
- claimed date
- invited email
- status

Admin should see all prior claim attempts.

## Step 9 - Listing Completeness
Add completeness indicators.

Example categories:
- core identity
- images
- facilities
- dietary
- accessibility
- destinations
- pricing
- availability
- contact/ownership

Example result:

```text
Damai I - 82% complete
Missing:
- hero image
- accessibility details
- current departures
```

Completeness must be informational, not a requirement for basic publication.

## Step 10 - Advanced Organisation Activity
Organisation page can show:
- users
- vessels
- resorts
- enquiries
- claim history
- imports affecting organisation
- verification
- recent changes
- last login/activity

## Step 11 - Website Source Queue
Build operational queue:

```text
/admin/v2/imports/website
```

Admin can enter:
- operator
- product type
- source URL
- product name
- notes

Statuses:

```text
queued
draft_created
needs_review
approved
rejected
```

Phase 2B should make this ready for Phase 5 automated extraction workers.

A sophisticated scraper/AI extractor is still not required in Phase 2B.


## Step 12 - Availability Source Management & Freshness

Build the management layer on top of the normalized Availability Service created in Phase 2A.

Phase 2B still does **not** need to connect to external providers. The goal is to make the availability system ready for those connectors.

### Admin visibility

For departure/cabin availability, admin should be able to see:

```text
effective availability status / quantity
source type
source name/reference
sourceUpdatedAt
receivedAt
freshness state
manual override state
```

### Freshness / stale rules

The system must distinguish between:

```text
fresh
aging
stale
unknown
```

The exact threshold should be configurable by source/source type rather than hard-coded into public-page components.

A stale value must **not automatically become sold out**.

Public/search APIs should be able to return freshness metadata so later customer UI can show:

```text
Updated 15 minutes ago
Updated yesterday
Availability may be outdated
Contact us to confirm
```

### Source configuration foundation

Create a connector/source configuration model suitable for later Phase 5 integrations.

Suggested non-secret metadata:

```text
providerName
sourceType
organisationId
product/external mapping references
enabled
priority
freshnessThresholdMinutes
lastSuccessfulSyncAt
lastAttemptAt
status
```

Do not store provider API credentials in ordinary catalogue records or audit logs.

Actual external credentials/integration secrets should later use environment/secret storage appropriate to the deployment platform.

### Multiple sources / conflicts

The architecture must allow more than one source to report availability for the same inventory.

Phase 2B should provide a basic resolution strategy:

- configurable source priority
- flag conflicting values
- allow admin to inspect competing source updates
- do not silently overwrite a higher-priority/current accepted source with an older/lower-priority value

Do not hard-code a universal provider ranking. Priority should be configurable because operators and feeds will differ.

### Manual override

Admin should be able to apply an explicit availability override with:

```text
value/status
reason
createdBy
createdAt
optional expiresAt
```

The UI must make clear when the effective availability is being driven by a manual override.

An expired override should stop controlling the effective value.

### Availability history

Retain enough history to answer:

```text
What did the source report?
When did it report it?
What became the effective availability?
Was there a manual override?
Why did the effective value change?
```

History does not need to become a full analytics warehouse, but important inventory changes should be traceable.

### Phase 5 connector readiness

The Phase 2B source configuration and Availability Service should allow later connectors such as:

```text
specialist liveaboard availability API
Bookinglayer-style booking platform API
operator proprietary API
JSON/XML feed
webhook
Google Sheet
SFTP/file feed
```

to feed the existing service without changing the search/public availability model.

## Step 13 - Advanced Dashboard
Add metrics such as:
- listings needing review
- stale listings
- imports with errors
- unclaimed operators
- expired invitations
- incomplete listings
- enquiries awaiting admin
- recently claimed organisations

## Step 14 - Bulk Admin Actions
Where safe, support:
- bulk publish
- bulk restrict
- bulk archive
- bulk assign destination
- bulk send invitations
- bulk mark for review

Bulk actions must show confirmation and results.

## Step 15 - Advanced Filters
Admin catalogue filters can include:
- operator
- publication status
- claim status
- verification
- destination
- country
- source
- completeness
- last updated
- has availability
- availability freshness
- availability source
- availability conflict/override state
- has pricing
- has images

## Step 16 - Operational Reporting
Provide useful operational summaries such as:
- catalogue growth
- claimed vs unclaimed
- published vs draft
- import success/error rate
- listings not checked recently
- enquiries by status
- stale availability count
- availability sources requiring attention
- recent availability sync/update failures

Keep this operational, not a full business intelligence platform.

---

# 4. Mobile Requirement

Phase 2B must retain the responsive rules from 2A.

Notification centre, duplicate review, audit search, and operator management should work on mobile, but complex reconciliation/import analysis may remain best on desktop.

No critical admin workflow should become unusable on phone.

---

# 5. Phase 2B Acceptance Criteria

Phase 2B is complete when:

- Import history is searchable and useful.
- Row-level import errors are visible.
- Ambiguous duplicates can be manually reconciled.
- Notification centre works.
- Unread count works.
- Audit log records important actions.
- Provenance/source information is visible.
- Verification controls work.
- Claim invitation history works.
- Completeness indicators work.
- Website source queue works.
- Admin can see availability source and last-update/freshness information.
- Stale availability is flagged and is not silently converted to sold out.
- Source priority can be configured for availability.
- Conflicting source values can be identified for review.
- Manual availability override works and is visibly distinguishable.
- Availability update/effective-value history is traceable.
- Connector/source configuration exists without requiring an external provider integration.
- Phase 2A normalized Availability Service remains the single write path for future adapters.
- Advanced dashboard highlights operational issues.
- Safe bulk admin actions work.
- Advanced catalogue filters work.
- Core Phase 2A workflows remain unchanged and stable.
- Mobile/tablet/desktop remain usable.
- No production V1 database is modified.

---

# 6. Phase 2B End-to-End Demonstration

Demonstrate:

```text
1. Run import with mixed valid/error/duplicate rows
2. Review import history
3. Open row-level error
4. Resolve ambiguous duplicate
5. Publish corrected record
6. Confirm audit log event
7. Confirm notification created
8. Mark listing verified
9. View provenance/last checked data
10. Review listing completeness
11. Add source URL to website queue
12. Create/configure a test availability source with a freshness threshold
13. Submit two source updates for the same inventory and demonstrate priority/conflict handling
14. Mark an old availability value stale without converting it to sold out
15. Apply a temporary manual availability override and confirm it is clearly identified
16. Review availability update/effective-value history
17. Run safe bulk action on test records
18. Confirm Phase 2A workflows still work
```

---

# 7. Non-Goals for Phase 2B

Not required:
- full automatic website scraping
- AI extraction pipeline
- actual external availability API/feed integrations (connector-ready architecture is required, provider connections are Phase 5)
- customer-facing V2 redesign
- full operator portal V2
- PWA
- agent platform
- native app

Those belong to later phases.

---

# 8. Handoff to Phase 3

After Phase 2B passes acceptance testing, proceed to **Phase 3 - Operator Portal V2**.
