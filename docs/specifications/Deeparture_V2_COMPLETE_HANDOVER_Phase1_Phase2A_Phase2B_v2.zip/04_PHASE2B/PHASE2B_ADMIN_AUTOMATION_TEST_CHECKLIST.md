# Deeparture V2 - Phase 2B Admin Automation Acceptance Checklist

**Revision 1.1 - Includes availability freshness, source priority/conflicts, overrides, history and connector-readiness tests.**

Use this checklist to confirm **Phase 2B - Admin Automation & Management Enhancements** is complete before moving on.

## Test environment

- Admin V2 URL: __________________________________________
- Frontend staging URL: __________________________________
- Backend/API URL: _______________________________________
- GitHub branch/commit: __________________________________
- Test date: _____________________________________________
- Tested by: _____________________________________________

## 1. Import History

- [ ] **Import batches are stored.**  
  _Verify:_ Timestamp/user/source/type/results available.
- [ ] **Row-level errors are visible.**  
  _Verify:_ Admin can understand failures.
- [ ] **Affected records can be opened.**  
  _Verify:_ History is operational.
- [ ] **Partial failures are clearly reported.**  
  _Verify:_ No hidden state.

## 2. Duplicate Reconciliation

- [ ] **Ambiguous matches enter review.**  
  _Verify:_ No silent merge.
- [ ] **Admin can choose existing/new.**  
  _Verify:_ Manual resolution works.
- [ ] **Resolved decision persists.**  
  _Verify:_ Future imports behave consistently where appropriate.

## 3. Notifications

- [ ] **In-app notification records are created.**  
  _Verify:_ Import/claim/enquiry/etc.
- [ ] **Unread count works.**  
  _Verify:_ Header/badge updates.
- [ ] **Notification links to correct record.**  
  _Verify:_ Actionable.

## 4. Audit & Provenance

- [ ] **Important admin actions create audit entries.**  
  _Verify:_ Actor/action/entity/time.
- [ ] **Sensitive secrets are excluded.**  
  _Verify:_ No passwords/tokens in payloads.
- [ ] **Source type/URL can be viewed.**  
  _Verify:_ Provenance visible.
- [ ] **Last checked/verified dates can be stored.**  
  _Verify:_ Future automation readiness.

## 5. Verification & Claim History

- [ ] **Admin can mark organisation verified.**  
  _Verify:_ Separate from publication.
- [ ] **Admin can mark listing verified.**  
  _Verify:_ Separate from publication.
- [ ] **Claim invitation history is visible.**  
  _Verify:_ Sent/expiry/resend/revoke/claimed.

## 6. Completeness & Website Queue

- [ ] **Listing completeness indicator works.**  
  _Verify:_ Shows missing categories.
- [ ] **Completeness does not block basic publication.**  
  _Verify:_ Informational only.
- [ ] **Website source queue accepts URL/product/operator.**  
  _Verify:_ Ready for Phase 5 extractor.
- [ ] **Website queue statuses work.**  
  _Verify:_ queued/draft_created/needs_review/etc.

## 7. Availability Source Management

- [ ] **Admin can see availability source and timestamps.**  
  _Verify:_ Effective availability displays source, sourceUpdatedAt and/or receivedAt as designed.
- [ ] **Freshness state is calculated/configurable.**  
  _Verify:_ Test data can become fresh/aging/stale/unknown based on configured rule.
- [ ] **Stale does not mean sold out.**  
  _Verify:_ Aging a record beyond its freshness threshold does not change inventory to sold_out automatically.
- [ ] **Source priority can be configured.**  
  _Verify:_ Priority is data/configuration, not a hard-coded universal provider ranking.
- [ ] **Conflicting source updates are detectable.**  
  _Verify:_ Admin can see when two sources disagree for the same inventory.
- [ ] **Older/lower-priority data cannot silently replace the accepted effective value.**  
  _Verify:_ Resolution logic is deterministic and reviewable.
- [ ] **Manual override works.**  
  _Verify:_ Admin can set value/status with reason and optional expiry.
- [ ] **Manual override is visibly identified.**  
  _Verify:_ Admin can tell effective availability is overridden.
- [ ] **Expired override stops controlling effective availability.**  
  _Verify:_ Resolution returns to the applicable source value.
- [ ] **Availability history is traceable.**  
  _Verify:_ Source updates, effective-value changes and overrides can be reviewed.
- [ ] **Availability source/connector configuration exists.**  
  _Verify:_ Provider/source mapping, enabled state, priority, freshness threshold and sync metadata can be stored.
- [ ] **No external provider connection is required to pass Phase 2B.**  
  _Verify:_ Connector-ready architecture is present but sharc/Bookinglayer/operator API integration remains deferred.
- [ ] **Future connectors still write through the Phase 2A Availability Service.**  
  _Verify:_ No second availability subsystem is introduced.

## 8. Advanced Admin Tools

- [ ] **Advanced dashboard flags operational issues.**  
  _Verify:_ Stale/error/unclaimed/etc.
- [ ] **Safe bulk admin actions work.**  
  _Verify:_ Confirm + result reporting.
- [ ] **Advanced catalogue filters work.**  
  _Verify:_ Status/source/completeness/etc.
- [ ] **Operational reporting is available.**  
  _Verify:_ Catalogue/import/claim/enquiry summaries.

## 9. Regression & Mobile

- [ ] **Phase 2A import workflow still works.**  
  _Verify:_ No regression.
- [ ] **Phase 2A claim workflow still works.**  
  _Verify:_ No regression.
- [ ] **Phase 2A enquiry workflow still works.**  
  _Verify:_ No regression.
- [ ] **Phase 2A normalized availability service still works.**  
  _Verify:_ New source/freshness features extend the same service rather than replacing it.
- [ ] **Phase 2B screens usable on desktop/tablet/mobile.**  
  _Verify:_ No critical layout break.
- [ ] **No V1 production data is modified.**  
  _Verify:_ Mandatory.
- [ ] **Ready for Phase 3.**  
  _Verify:_ All critical tests pass.

## Final Result

- [ ] PASS - Phase 2B - Admin Automation & Management Enhancements accepted
- [ ] PASS WITH ISSUES - non-critical issues documented
- [ ] FAIL - Phase 2B - Admin Automation & Management Enhancements not ready to move on

### Outstanding issues

1. _________________________________________________
2. _________________________________________________
3. _________________________________________________
4. _________________________________________________

## Next phase

Once this passes, proceed to **Phase 3 - Operator Portal V2**.