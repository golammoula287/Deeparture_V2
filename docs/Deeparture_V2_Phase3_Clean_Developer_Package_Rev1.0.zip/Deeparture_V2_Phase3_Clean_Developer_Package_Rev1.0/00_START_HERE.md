# Deeparture V2 — Phase 3 Operator Portal
## Clean Developer Package — Revision 1.0

### AUTHORITATIVE BASELINE

Phase 3 must be integrated from the exact deployed Phase 2B Rev 1.3 baseline:

`01cb93ea3ce312ef0227099bd224094b2072ddb8`

Confirmed before Phase 3 implementation:
- Frontend Render Live commit: `01cb93ea3ce312ef0227099bd224094b2072ddb8`
- Backend Render Live commit: `01cb93ea3ce312ef0227099bd224094b2072ddb8`
- Dedicated V2 Atlas staging database: confirmed
- Phase 2B availability fixes: confirmed passing on Render staging
- Exact deployed source approved as the Phase 3 branch point

### WHAT TO USE

Start with:

`01_IMPLEMENTATION/Deeparture_V2_Phase3_Operator_Portal_Implementation_Rev1.0.zip`

That is the complete Phase 3 source package.

The raw patch and patch-handover ZIP are supplied as reproducible alternatives/evidence. Do not apply the full source ZIP and raw patch on top of each other as separate code changes; they represent the same Phase 3 implementation in different handover forms.

Use the files in `02_ACCEPTANCE_AND_HANDOVER` for deployment notes and staging acceptance.

The documents in `03_REFERENCE_ARCHITECTURE` are supporting architecture/roadmap references. Where a generic roadmap statement differs from the implementation-specific handover/checklist, the implementation-specific files in this package are authoritative for Phase 3 Rev 1.0.

### IMPORTANT MEDIA DECISION

Phase 3 media management is provider-agnostic. The implementation manages scoped media records/URLs and preserves a migration path for existing gallery URLs.

Do not introduce persistent image binaries on Render's ephemeral local filesystem.

A durable object-storage provider such as S3, Cloudinary, or equivalent can be connected later without redesigning the Operator Portal domain layer.

### IMPLEMENTATION PRINCIPLE

The Operator Portal must remain a permissioned interface over the existing shared Deeparture V2 services. Do not create parallel operator-only catalogue, pricing, availability, enquiry, notification, organisation, claim, or import systems.

### VERIFICATION ALREADY COMPLETED DURING PACKAGING

- Phase 3 static verifier: PASS
- New Phase 3 unit tests: 6/6 PASS
- Backend JavaScript syntax: 111 files PASS
- Frontend JS/JSX syntax: 63 files PASS
- Phase 2B -> Phase 3 raw patch applies cleanly to the authoritative baseline

### DEVELOPER DEPLOYMENT / ACCEPTANCE

The developer should:
1. Branch from or verify against commit `01cb93ea3ce312ef0227099bd224094b2072ddb8`.
2. Integrate the Phase 3 source.
3. Install dependencies using the repository lockfiles.
4. Run the complete backend regression/test suite, including prior Phase 1/2A/2B tests.
5. Run the Next.js production build.
6. Apply any included database migration/backfill steps in staging first.
7. Deploy frontend/backend to Render staging.
8. Verify the deployed commit hashes.
9. Work through `Deeparture_V2_Phase3_Acceptance_Checklist_Rev1.0.md`.
10. Return the final Phase 3 branch/commit, deployed hashes, test/build evidence, and completed acceptance checklist.

### SUPERSEDED DOCUMENTS INTENTIONALLY EXCLUDED

The earlier Phase 3 developer package contained planning documents referring to provisional Phase 2B commit `df61c280abac73f21765d3eb4a9f7285d25231f8` and an older image-upload checklist.

Those documents are intentionally not included here because they are superseded by this implementation-specific handover and the authoritative baseline above.

This package is intended to be the single developer handover for Phase 3 Rev 1.0.
