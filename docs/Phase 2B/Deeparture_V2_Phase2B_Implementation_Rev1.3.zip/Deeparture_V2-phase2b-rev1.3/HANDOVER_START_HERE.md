# Deeparture V2 - Phase 2B Rev 1.3 Implementation Handover

This checkout is the **Phase 2B Rev 1.3 implementation** built directly on the accepted Phase 2A integration baseline:

- Phase 2A branch: `phase2a-integration`
- Phase 2A commit: `68e30d61f969aa59d450b8b7038ca39475b624b1`

## Read first

1. `PHASE2B_IMPLEMENTATION_HANDOVER_REV1.3.md`
2. `docs/phase2b/IMPLEMENTATION_AND_DEPLOYMENT.md`
3. `docs/phase2b/MIGRATIONS_AND_ROLLBACK.md`
4. `docs/phase2b/INDEX_PLAN.md`
5. `docs/phase2b/LOCAL_ACCEPTANCE.md`
6. `docs/phase2b/specifications/Deeparture_V2_Phase2B_Admin_Automation_Developer_Specification_Rev1.3.pdf`
7. `docs/phase2b/specifications/Deeparture_V2_Phase2B_Admin_Automation_Test_Checklist_Rev1.3.pdf`

`PHASE2B_IMPLEMENTATION_MANIFEST.json` records the baseline identity, implementation delta and packaging-time verification results.

## Developer workflow

The substantive Phase 2B application code is already included. The integration/deployment developer should:

1. start from the exact Phase 2A baseline above, or use this complete checkout
2. run `npm ci` in `backend/` and `frontend/`
3. run the backend syntax/static/test/regression checks described in the handover
4. run the frontend production build
5. resolve only concrete merge/environment issues
6. deploy to Render staging
7. connect the dedicated Atlas V2 staging environment when the project moves off local MongoDB
8. run the Phase 2B Rev 1.3 acceptance checklist against deployed staging
9. record the exact deployed branch/commit and any integration changes

Do **not** rebuild Phase 2B as a parallel subsystem. Phase 2B extends the Phase 2A normalized import, availability, pricing, search, organisations/claims, enquiry, locations, attributes and audit foundations.

The original Phase 2A handover text has been preserved at `docs/phase2a/HANDOVER_START_HERE_PHASE2A.md` for historical reference.
