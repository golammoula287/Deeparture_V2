# Deeparture V2 - Phase 3 Operator Portal V2
## Acceptance Checklist - Code-Aware Revision 1.0

Use this checklist against the final Phase 3 deployed staging revision.

## Test environment

- Operator Portal URL:
- Frontend staging URL:
- Backend/API URL:
- Atlas staging database:
- Git branch:
- Full commit:
- Test date / tester:

---

## 1. Baseline & Regression

- [ ] **Phase 3 branches from the final corrected Phase 2B commit.**  
  _Verify:_ Full immutable Phase 2B baseline hash is recorded.
- [ ] **Phase 1 + Phase 2A + Phase 2B regression suites remain green.**  
  _Verify:_ Auth, Admin, claiming, imports, search, pricing, availability, enquiries and public pages remain functional.
- [ ] **V1 production data is not modified.**
- [ ] **Dedicated V2 Atlas staging database is used.**

## 2. Operator Portal Shell

- [ ] **Dedicated Operator Portal exists.**
- [ ] **Operator can select/switch among organisations they belong to.**
- [ ] **Organisation with liveaboards and resorts sees both in one portal.**
- [ ] **Product-aware navigation hides irrelevant modules.**
- [ ] **Capability-aware navigation hides unauthorized actions.**
- [ ] **Admin V2 remains separate from Operator Portal.**

## 3. Capability Permissions & Ownership

- [ ] **Capability permission resolution exists.**
- [ ] **Existing membership roles remain migratable/backward compatible.**
- [ ] **Owner/Admin preset works.**
- [ ] **Reservations preset cannot manage organisation users.**
- [ ] **Content/Marketing preset cannot alter booking-sensitive pricing/availability unless granted.**
- [ ] **Read Only cannot write.**
- [ ] **Suspended/disabled membership loses access.**
- [ ] **Operator A cannot read Operator B private resources.**
- [ ] **Operator A cannot update Operator B vessel/resort.**
- [ ] **Operator A cannot update Operator B itinerary/departure/room/package/rates.**
- [ ] **Operator A cannot alter Operator B pricing/availability/offers.**
- [ ] **Operator A cannot access Operator B enquiries/import history/media/users.**
- [ ] **Changing organisation/resource IDs in URL/body does not bypass ownership.**
- [ ] **Existing resource ownership cannot be reassigned by update body.**

## 4. Claim & Onboarding

- [ ] **Claim acceptance reuses existing organisation/listings.**
- [ ] **Claim does not create duplicate organisation/product records.**
- [ ] **Expired/invalid/already-used claim tokens are handled safely.**
- [ ] **Onboarding shows claimed organisation and associated products.**
- [ ] **Onboarding shows listing/verification/completeness context.**
- [ ] **Operator lands in correct organisation portal after activation.**

## 5. Organisation Users

- [ ] **Authorized user can list organisation members.**
- [ ] **Authorized user can invite colleague by email.**
- [ ] **Role/capability preset is selected at invitation.**
- [ ] **Invitation is expiring and single-use.**
- [ ] **Resend/revoke invitation works.**
- [ ] **Disable/reactivate member works.**
- [ ] **Role/capability update works.**
- [ ] **Duplicate membership/invitation is prevented.**
- [ ] **Cannot grant Deeparture internal Admin privilege.**
- [ ] **Final owner cannot be accidentally removed without safe transfer.**
- [ ] **Member changes are audited.**

## 6. Liveaboard - Vessel & Attributes

- [ ] **Operator can open/edit owned vessel.**
- [ ] **Operator can manage operator-editable facilities/attributes.**
- [ ] **Typed attributes preserve boolean/number/select/multi-select values.**
- [ ] **Operator cannot change Deeparture vegan/editorial rating.**
- [ ] **Operator cannot change verification/publication state.**
- [ ] **Major catalogue edits follow configured moderation policy.**
- [ ] **Last approved public version is preserved if moderation is required.**

## 7. Liveaboard - Itineraries & Base Pricing

- [ ] **Operator can list/create/edit itinerary.**
- [ ] **Itinerary remains tied to an owned vessel.**
- [ ] **Canonical destinations/ports are used.**
- [ ] **Duration/dives/certification/minimum logged dives can be managed.**
- [ ] **Cabin-level base prices can be managed.**
- [ ] **Updating itinerary pricing reprices applicable departures through shared pricing service.**
- [ ] **Referenced itinerary is archived/deactivated safely rather than destructively lost.**

## 8. Liveaboard - Departures, Availability & Offers

- [ ] **Operator can create/edit an owned departure.**
- [ ] **Operator can duplicate/copy departure/season where implemented.**
- [ ] **Departure-specific price override works.**
- [ ] **Effective price uses shared pricing service.**
- [ ] **Availability update uses normalized Availability Service.**
- [ ] **Operator can update spaces/cabins quickly.**
- [ ] **available/limited/sold_out/on_request states work.**
- [ ] **Last update/source information is visible.**
- [ ] **Admin manual override is visibly controlling when active.**
- [ ] **Older operator update cannot silently overwrite newer accepted source data.**
- [ ] **Structured offer can be created/edited/expired.**
- [ ] **Expired offer stops affecting effective price automatically.**

## 9. Resort - Property, Rooms & Packages

- [ ] **Operator can open/edit owned resort.**
- [ ] **Deeparture-controlled editorial fields remain protected.**
- [ ] **Room type can be created/edited/archived.**
- [ ] **Room type ownership/resort relationship is enforced.**
- [ ] **Package can be created/edited/archived.**
- [ ] **Package remains separate from seasonal rates.**
- [ ] **Operator can manage resort attributes/dietary/diving data.**

## 10. Resort - Rates, Availability, Stop-sell & Offers

- [ ] **Rate period can be created/edited.**
- [ ] **Native supplier currency/amount remains authoritative.**
- [ ] **Invalid/ambiguous overlapping rates are handled.**
- [ ] **Resort availability uses normalized Availability Service.**
- [ ] **Stop-sell/closure date ranges can be represented.**
- [ ] **Multiple stop-sell ranges are supported where required.**
- [ ] **Resort offer can be created/edited/expired.**
- [ ] **Liveaboard functionality remains unaffected by resort workflows.**

## 11. Media Management

- [ ] **Operator can upload an image for an owned product.**
- [ ] **Persistent media storage is not Render local disk.**
- [ ] **Media Service/storage adapter boundary exists.**
- [ ] **Operator can replace/remove/archive image.**
- [ ] **Operator can edit title/alt text.**
- [ ] **Gallery ordering works.**
- [ ] **Featured image selection works.**
- [ ] **Media cannot be attached to another organisation's product.**
- [ ] **Source/usage approval/provenance metadata is retained.**

## 12. Operator Bulk Uploads

- [ ] **Upload does not write during preview.**
- [ ] **CSV works.**
- [ ] **XLSX works.**
- [ ] **Source adapter maps to normalized DTO/service contract.**
- [ ] **Ownership is validated for every referenced product.**
- [ ] **Preview shows CREATE/UPDATE/DUPLICATE_REVIEW/ERROR-SKIP or equivalent.**
- [ ] **Operator confirms before commit.**
- [ ] **Confirmed commit writes via shared domain services.**
- [ ] **ImportBatch/history is created.**
- [ ] **Operation ID is visible/traceable.**
- [ ] **Per-row error/outcome reporting works.**
- [ ] **Idempotent re-upload does not duplicate stable records.**
- [ ] **File/row limits are enforced.**
- [ ] **Macros are not executed.**
- [ ] **Supported liveaboard import types work.**
- [ ] **Supported resort import types work.**

## 13. Enquiries

- [ ] **Operator only sees enquiries after Admin dispatch/approval.**
- [ ] **Operator cannot see another organisation's enquiry.**
- [ ] **Inbox filters work.**
- [ ] **Enquiry detail/status history works.**
- [ ] **Allowed operator state transitions work.**
- [ ] **Invalid state transitions are rejected.**
- [ ] **Operator reply/status change creates audit/domain event.**
- [ ] **Admin-first workflow remains intact.**
- [ ] **Phase 3 does not introduce an unintended payment/booking engine.**

## 14. Operator Notifications

- [ ] **Phase 2B notification service is reused.**
- [ ] **Notifications are recipient/organisation aware.**
- [ ] **Unread count works.**
- [ ] **Mark read works.**
- [ ] **Notification link opens correct operator record.**
- [ ] **Notification history is paginated.**
- [ ] **Operator cannot read another organisation/user's private notification.**
- [ ] **Email remains a channel/service rather than controller-coupled logic.**

## 15. Mobile-First UX

- [ ] **Portal works at approximately 390 px width.**
- [ ] **Portal works at approximately 768 px width.**
- [ ] **Portal works at approximately 1440 px width.**
- [ ] **Availability quick edit is practical on phone.**
- [ ] **Price quick edit is practical on phone.**
- [ ] **Offer create/expire is practical on phone.**
- [ ] **Enquiry response is practical on phone.**
- [ ] **Image upload/selection is practical on phone.**
- [ ] **Import preview can be reviewed on phone without unusable horizontal tables.**
- [ ] **No critical horizontal squeeze/overflow.**

## 16. Engineering Guardrails

- [ ] **Phase 3 migrations/backfills are documented.**
- [ ] **Rollback/recovery path is documented.**
- [ ] **Operator query/index plan is documented.**
- [ ] **Growing lists use server-side pagination/sorting.**
- [ ] **Bounded page sizes are enforced.**
- [ ] **Concurrency/lost-update protection exists where material.**
- [ ] **Explicit conflict response works.**
- [ ] **Consistent API error contract is used.**
- [ ] **No stack traces/secrets leak to client.**
- [ ] **Multi-step actions have operation IDs.**
- [ ] **Bulk operations are bounded and show partial outcomes.**
- [ ] **Important operator writes create audit/provenance records.**
- [ ] **Realistic seeded-data performance check passes.**
- [ ] **No obvious N+1/full-collection browser filtering is introduced.**
- [ ] **No unnecessary heavy infrastructure is added.**

## 17. End-to-End Demonstration

- [ ] **Claim existing unclaimed organisation without duplicate creation.**
- [ ] **Invite second operator user with restricted capability set.**
- [ ] **Restricted user is prevented from unauthorized action.**
- [ ] **Edit vessel content without changing Deeparture-controlled fields.**
- [ ] **Create/edit itinerary and base price.**
- [ ] **Create departure and update availability.**
- [ ] **Create/expire an offer and verify effective price.**
- [ ] **Create/edit resort room, package and rate.**
- [ ] **Create resort stop-sell/availability update.**
- [ ] **Upload/manage an image through persistent media service.**
- [ ] **Run operator XLSX import preview with valid/error/duplicate rows.**
- [ ] **Confirm import and show history/audit/operation ID.**
- [ ] **Receive/respond to an Admin-approved enquiry.**
- [ ] **Receive/read actionable operator notification.**
- [ ] **Demonstrate cross-organisation access denial.**
- [ ] **Demonstrate one concurrency/conflict case.**
- [ ] **Confirm full Phase 1 + Phase 2 regression suite remains green.**
- [ ] **Confirm Render + Atlas + exact branch/commit identity.**

---

## Final Result

- [ ] PASS - Phase 3 accepted
- [ ] PASS WITH ISSUES - non-critical issues documented
- [ ] FAIL - Phase 3 not ready for Phase 4

Outstanding issues:

1.
2.
3.
4.

**Next phase:** Phase 4 - Customer Frontend V2 + PWA
