# Deeparture V2 - Phase 3 Rev 1.0 - START HERE

This package defines the code-aware Phase 3 Operator Portal V2 implementation.

## Read in this order

1. `Deeparture_V2_Phase3_Operator_Portal_Code_Aware_Developer_Specification_Rev1.0.pdf`
2. `PHASE3_IMPLEMENTATION_DELTA_FROM_PHASE2B_REV1.0.md`
3. `Deeparture_V2_Phase3_Operator_Portal_Test_Checklist_Rev1.0.pdf`
4. Complete Platform Architecture / Future-Proof Architecture Principles / Six-Phase Roadmap

## Baseline

Phase 3 must branch from the final immutable corrected Phase 2B Rev 1.3 commit.

The current corrected source package reviewed for this specification is:

`Deeparture_V2_Source_Code_Rev1.3.zip`

Its `SOURCE_README.md` states the corrections were based on commit:

`df61c280abac73f21765d3eb4a9f7285d25231f8`

but the package did not yet record a corrected commit hash.

Do not begin the final Phase 3 merge/deployment from an ambiguous older baseline.

## Most important implementation rules

- reuse existing shared services
- complete capability-based operator permissions
- enforce permission + membership + ownership on every write
- refactor operator bulk upload to preview/confirm/commit
- preserve Admin-first enquiry flow
- use normalized Availability Service and shared pricing
- build persistent media storage behind a Media Service adapter
- keep resorts commercially separate from liveaboard departures
- make routine workflows mobile-first
- keep external provider integrations in Phase 5

## Developer role

As with Phase 2, the intended workflow is:

- OpenAI/Deeparture implementation work builds the Phase 3 code against the exact final baseline
- development team integrates/merges
- development team runs full dependency/build suite
- development team handles Render/Atlas/environment-specific issues
- development team deploys to staging
- acceptance checklist is run against deployed staging
