# Deeparture V2 - Phase 3
## Implementation Delta From Final Phase 2B Rev 1.3 - Revision 1.0

This file is the code-aware implementation map for the Phase 3 developer.

## Current source findings

The final Phase 2B Rev 1.3 source already contains substantial Operator Portal foundations.

### Existing operator access

Current backend contains:

- `OrganisationMembershipV2`
- `organisationAccess` middleware
- `/api/v2/organisations/mine`
- organisation dashboard
- operator-owned vessel/resort/inventory writes
- operator enquiry status route

Current membership roles are:

```text
owner
admin
editor
reservations
viewer
```

Current access control uses a numeric role hierarchy. Phase 3 should preserve compatibility while introducing capability checks.

### Existing dashboard

Current frontend:

`frontend/pages/dashboard/v2/index.jsx`

already:

- lists the user's organisations
- switches organisation
- shows liveaboard/resort/enquiry counts
- lists vessels and resorts
- provides direct CSV/XLSX inventory upload

Phase 3 should refactor this into modular Operator Portal navigation rather than discard the working organisation-selection/session foundation.

### Existing operator inventory writes

Current organisation routes already expose creation/editing for:

- vessels
- itineraries
- departures
- resorts
- room types
- resort packages
- rate periods
- resort availability
- typed product attributes
- enquiry status updates

These must be extended rather than recreated.

### Existing ownership protection

Current inventory writes constrain records by organisation and prevent changing ownership/parent identifiers on existing records.

Keep this pattern and strengthen it with capability authorization and cross-organisation tests.

### Deeparture-controlled fields

Current vessel/resort updates already block operator changes to fields such as:

```text
veganRating
environmentalRating
verificationStatus
listingStatus
```

Preserve this boundary.

### Pricing

Current inventory controller already delegates effective liveaboard pricing to the shared pricing service.

Do not recreate pricing calculations in Phase 3 frontend components.

### Availability

Current liveaboard and resort inventory writes already delegate to the normalized Availability Service.

Phase 3 should build fast operator workflows around this service.

### Enquiries

Current operator enquiry controller only allows selected operator transitions and checks organisation ownership.

Phase 3 should add a real inbox/detail UI and preserve the Admin-first dispatch rule.

### Media

`MediaAssetV2` exists but the current source does not provide a complete operator media upload/storage workflow.

Phase 3 needs a storage abstraction and operator Media Manager.

### Important import gap

Current route:

```text
POST /organisations/:organisationId/import/:importType
```

parses CSV/XLSX and then immediately calls `importInventoryRows(...)`, which writes data.

This is the most important Phase 3 refactor.

Operator imports must use the normalized Phase 2A/2B import architecture:

```text
upload
-> normalize
-> validate
-> match
-> preview
-> confirm
-> commit
-> history
```

The operator should see create/update/duplicate/error outcomes before commit.

### Resort CRUD gap

RoomType, ResortPackage and ResortRatePeriod currently have create routes, but the Operator Portal needs complete edit/archive/update flows as appropriate.

Do not solve this by replacing the resort domain model with liveaboard departure logic.

## Phase 3 development priority

### P0 - security and architecture

- final Phase 2B commit identity
- capability permission layer
- membership/resource ownership tests
- operator API boundary
- import preview/confirm refactor
- media storage abstraction

### P1 - core portal

- portal shell/navigation
- onboarding/claim completion
- organisation member management
- liveaboard module
- resort module
- enquiry inbox
- notifications

### P2 - UX/productivity

- mobile quick actions
- season/departure duplication
- richer bulk upload tools
- image ordering/featured selection
- dashboard operational alerts
- operator import history/report download

## Do not rebuild

Do not build new parallel versions of:

- Organisation
- claim service
- pricing service
- Availability Service
- notifications
- audit/provenance
- typed attributes
- canonical locations
- enquiry model/workflow
- source mappings
- ImportBatch/history
