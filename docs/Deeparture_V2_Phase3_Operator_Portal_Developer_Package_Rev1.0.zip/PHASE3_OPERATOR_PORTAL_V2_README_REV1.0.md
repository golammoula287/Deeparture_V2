# Deeparture V2 - Phase 3 Operator Portal V2
## Code-Aware Developer Specification - Revision 1.0

**Status:** Ready for implementation planning after Phase 2B Rev 1.3 sign-off  
**Date:** 21 October 2026

## 1. Objective

Phase 3 turns the existing operator foundations into a complete, secure, mobile-first Operator Portal.

The operator should be able to claim/activate an existing catalogue-first organisation, manage one or more liveaboards and/or resorts, invite colleagues, maintain product content, pricing, availability, offers, media and enquiries, and use validated bulk uploads without requiring Deeparture Admin to perform routine updates.

The portal must reuse the shared services already implemented in Phase 1, Phase 2A and Phase 2B.

> **Primary rule:** Phase 3 is an operator-facing product layer over the existing Deeparture domain services. Do not build parallel pricing, availability, import, notification, audit, organisation, enquiry, attribute, search or source-mapping systems.

---

# 2. Authoritative Baseline

Implementation must be based on the final Phase 2B Rev 1.3 corrected source package and its eventual immutable Git commit.

Current reviewed source package:

`Deeparture_V2_Source_Code_Rev1.3.zip`

The supplied source package currently states that its corrected files are based on commit:

`df61c280abac73f21765d3eb4a9f7285d25231f8`

and that the corrections were uncommitted at packaging time.

Before Phase 3 implementation is merged/deployed, record the final Phase 2B corrected commit hash and use that exact revision as the Phase 3 branch point.

---

# 3. Reuse / Extend / Refactor / Build-New Summary

## Reuse

Reuse the existing:

- authentication and V2 user session
- Organisation and OrganisationMembership models
- claim token / claim acceptance flow
- organisation ownership middleware
- Vessel / CabinType / Itinerary / Departure models
- pricing service and effective pricing rules
- normalized Availability Service
- availability freshness/conflict/history/source mapping foundations
- Resort / RoomType / ResortPackage / ResortRatePeriod / ResortAvailability models
- typed attributes and AttributeDefinition system
- canonical locations
- reusable notifications
- audit/provenance and domain events
- Admin-first Enquiry model/workflow
- ImportBatch/history/provenance infrastructure
- API error/operation ID conventions
- pagination, concurrency and Rev 1.3 engineering guardrails

## Extend

Extend:

- OrganisationMembership into operator staff invitation and management
- claim acceptance into operator onboarding
- operator dashboard into a modular Operator Portal
- inventory CRUD into complete operator editing flows
- enquiry status handling into an operator inbox/detail experience
- notifications into an operator notification centre
- media metadata into a real upload/manage workflow
- normalized import/history infrastructure into operator-facing preview/confirm imports
- pricing/availability services into fast mobile editing workflows

## Refactor

Refactor:

- numeric/hierarchical operator role gating into capability-based permissions
- direct operator inventory upload into preview -> validate -> confirm -> commit -> history
- monolithic `/dashboard/v2` into dedicated modules/routes
- frontend direct fetch duplication into a shared Operator Portal API/client layer
- any route that trusts organisation identifiers from request bodies instead of authenticated membership context
- resort creation-only routes into full CRUD/update flows where required

## Build New

Build new:

- Operator Portal navigation/layout
- operator onboarding/activation screens
- organisation user invite/manage screens
- capability permission resolution
- vessel/resort modular editors
- liveaboard itinerary/departure/pricing/availability/offer screens
- resort room/package/rate/availability/stop-sell/offer screens
- operator media manager
- operator notification centre
- operator enquiry inbox/detail UI
- operator import preview/confirm/history UI
- mobile quick-update experiences
- operator-specific regression/security acceptance tooling

---

# 4. Operator Portal Information Architecture

One authenticated operator session may belong to one or more organisations.

Recommended portal structure:

```text
OPERATOR PORTAL
|
|-- Overview
|-- My Liveaboards
|   |-- Vessels
|   |-- Itineraries
|   |-- Departures
|   |-- Pricing
|   |-- Availability
|   `-- Offers
|-- My Resorts
|   |-- Resorts
|   |-- Room Types
|   |-- Packages
|   |-- Rates / Seasons
|   |-- Availability / Stop-sell
|   `-- Offers
|-- Enquiries
|-- Bulk Uploads
|-- Media
|-- Notifications
|-- Organisation Users
`-- Account / Security
```

Navigation must be capability-aware and product-aware.

Examples:

- resort-only operator should not be forced through liveaboard menus
- liveaboard-only operator should not see irrelevant resort management
- an organisation owning both should see both in one portal
- a Reservations user should not see organisation-user administration controls
- a Read Only user should not see edit/save actions

---

# 5. Identity, Memberships & Capability Permissions

## 5.1 Existing limitation

The current organisation middleware uses hierarchical roles:

```text
viewer < reservations < editor < admin < owner
```

This is insufficient for Phase 3 because operator responsibilities are not strictly hierarchical.

For example:

- Content/Marketing may edit descriptions and images but not availability
- Reservations may manage availability, pricing and enquiries but not organisation users
- Owner/Admin may manage all organisation capabilities
- Read Only may inspect but never write

## 5.2 Required capability model

Introduce capability-based permission resolution while retaining current membership roles for migration/backward compatibility.

Recommended permission keys:

```text
organisation.read
organisation.manage
organisation.members.read
organisation.members.manage

vessel.read
vessel.create
vessel.update
itinerary.read
itinerary.manage
departure.read
departure.manage

resort.read
resort.create
resort.update
roomType.manage
resortPackage.manage
resortRate.manage

pricing.read
pricing.manage
availability.read
availability.manage
offer.read
offer.manage

attribute.read
attribute.manage
media.read
media.manage

enquiry.read
enquiry.update

import.read
import.execute

notification.read
```

Permissions may be derived from role presets initially.

## 5.3 Suggested role presets

### Owner
All organisation-level and product-level permissions.

### Administrator
All operational permissions except ownership-transfer/destructive account-owner actions where restricted.

### Reservations
- departure.manage
- pricing.manage
- availability.manage
- offer.manage
- enquiry.read/update
- import.execute for inventory-related import types

### Content / Marketing
- vessel.update
- resort.update
- itinerary.manage where content-only policy permits
- attribute.manage where operator-editable
- media.manage
- selected offer/content capabilities if desired
- no booking-sensitive organisation/user administration

### Read Only
Read permissions only.

## 5.4 Authorization rule

Every protected write must pass:

```text
authenticated user
+ active organisation membership
+ required capability
+ resource belongs to authenticated organisation
+ organisation is not suspended
```

Never accept `organisationId` in a request body as proof of ownership.

---

# 6. Operator Claim & Onboarding

The catalogue-first model remains authoritative:

```text
Deeparture creates/imports organisation + products
-> listing may be public while unclaimed
-> claim invitation is issued
-> operator claims existing organisation
-> membership activates
-> operator maintains authorised data
```

Phase 3 must not create a second organisation or duplicate product during claim.

## Onboarding flow

After claim acceptance:

1. show organisation being claimed
2. show associated vessels/resorts
3. confirm user/profile details
4. show verification/listing status
5. show completeness gaps
6. identify Deeparture-controlled fields
7. guide operator to first useful actions
8. land in Operator Portal overview

Claim expiry, invalid token and already-claimed states must be handled clearly.

---

# 7. Organisation User Management

Build operator staff management around OrganisationMembership.

Owner/Admin-capable users should be able to:

- list organisation members
- invite a user by email
- select a role/capability preset
- resend invitation
- revoke an unaccepted invitation
- disable/suspend member access
- reactivate where allowed
- change a member's role/capabilities
- see invited/active/disabled state
- see invitation/member audit history

Requirements:

- unique organisation + user membership
- no duplicate invitations creating duplicate memberships
- invitation tokens must be expiring and single-use
- permission changes are audited
- an operator cannot grant Deeparture internal/admin privileges
- prevent accidental removal of the final active owner without a safe ownership transfer flow

---

# 8. Operator Overview Dashboard

The current dashboard is a useful foundation but should become operational.

Recommended cards/alerts:

- owned liveaboards/resorts
- upcoming departures
- stale/aging availability
- sold-out / limited inventory
- active and expiring offers
- incomplete listings
- pending/operator-action enquiries
- recent imports and failures
- unread notifications
- verification/completeness status

Quick actions on mobile:

- update spaces
- set sold out/on request
- add/expire offer
- update price
- respond to enquiry
- upload image
- open import preview

---

# 9. Liveaboard Operator Module

## 9.1 Vessel editor

Operators may edit operator-owned business content such as:

- vessel name/details where policy permits
- descriptions
- facilities/attributes
- dietary information
- accessibility information
- diving/technical support fields
- cabin information
- operator-managed media

Deeparture-controlled fields remain protected, including:

- Deeparture vegan/editorial rating
- verification state
- publication/moderation state
- editorial ranking/featured placement
- other Admin-only curation fields

## 9.2 Itineraries

Operator can:

- list itineraries by vessel
- create/edit route template
- assign canonical destinations/ports
- set duration/dives/minimum certification/minimum logged dives
- manage cabin-level base pricing
- duplicate an itinerary where useful
- deactivate/archive rather than destructively delete when referenced

Existing pricing service remains authoritative.

## 9.3 Departures

Operator can:

- add/edit departures
- duplicate/copy a seasonal pattern
- set dates/status
- assign itinerary
- set departure-specific price overrides
- update availability
- manage offers
- see effective price and inherited base price
- see freshness/source metadata where useful

Do not calculate effective price independently in the frontend.

## 9.4 Availability

Build a fast table/card workflow around the existing normalized Availability Service.

Operator should be able to:

- update spaces/cabins
- mark available / limited / sold out / on request
- update multiple cabins for one departure
- see last update time
- see when an Admin manual override is controlling effective availability
- avoid silently overwriting a newer accepted source update

Operator writes use `sourceType=operator` or a more specific normalized operator source.

## 9.5 Offers

Support structured offers such as:

- last-minute percentage
- early-bird percentage
- fixed-price or fixed-reduction if existing pricing model supports it
- cabin-specific offer
- date validity
- offer expiry
- active/inactive state

Expired offers must stop affecting effective price without manual cleanup.

---

# 10. Resort Operator Module

Do not reuse the liveaboard fixed-departure model for resorts.

Recommended modular editor:

```text
My Resorts
|-- Overview / Listing status
|-- Property details
|-- Rooms
|-- Packages
|-- Rates & Seasons
|-- Availability / Stop-sell
|-- Offers
|-- Facilities & Attributes
|-- Images
|-- Dietary & Vegan questionnaire
|-- Diving
|-- Enquiries
`-- Bulk Uploads
```

## 10.1 Rooms

Support full create/edit/archive operations for RoomType.

Important fields may include:

- room name/code
- occupancy
- room count
- facilities/attributes
- accessibility-related fields
- media links where applicable

## 10.2 Packages

Support full create/edit/archive operations for ResortPackage.

Package definition remains separate from date-based rate periods.

## 10.3 Rates & Seasons

Operator can:

- create/edit rate periods
- associate package and optional room type
- define valid date ranges
- preserve native currency/amount
- avoid destructive currency normalization

Overlapping/ambiguous rate periods should be validated.

## 10.4 Availability / Stop-sell

Support:

- room/date availability
- multiple stop-sell/closure ranges
- available / limited / sold out / on request where appropriate
- normalized Availability Service integration
- source/update timestamps

## 10.5 Resort offers

Use structured offers rather than legacy free-text discounts.

---

# 11. Media Management

Phase 3 must build the real operator media workflow.

## Requirements

Operator should be able to:

- upload image
- replace image
- remove/archive image
- edit title/alt text
- reorder gallery
- choose featured image
- assign image to vessel/resort/room/other supported target
- view usage/approval state
- avoid editing media owned by another organisation

## Storage rule

Do not store persistent uploads on Render's ephemeral local filesystem.

Use:

```text
Operator UI
-> Media Service
-> Storage Adapter
-> persistent object storage/CDN
-> MediaAsset metadata in MongoDB
```

The storage adapter must allow future provider change without rewriting product models.

## Rights/provenance

Retain:

- source
- source URL/reference
- usage approval
- uploaded by
- timestamps

---

# 12. Operator Bulk Uploads

The existing `/organisations/:organisationId/import/:importType` route immediately writes inventory after file parsing.

Phase 3 must refactor operator imports to reuse the normalized Phase 2A/2B workflow.

Required workflow:

```text
upload
-> parse adapter
-> normalized DTO
-> ownership validation
-> validation/matching
-> preview
-> CREATE / UPDATE / DUPLICATE_REVIEW / ERROR-SKIP
-> operator confirmation
-> controlled commit
-> ImportBatch history/audit
-> per-row results
```

No database write should occur during preview.

## Supported Phase 3 upload categories

At minimum:

- liveaboard itineraries/base prices
- departures
- availability
- departure overrides/offers
- resort rooms
- resort packages
- rate periods
- resort availability / stop-sell
- resort offers

CSV remains interoperable; XLSX is preferred for operator use.

## Import safety

- stable internal IDs
- optional operator external IDs
- idempotent re-upload
- ownership validation on every referenced entity
- maximum rows/file size
- operation ID
- per-row errors
- partial outcome reporting
- downloadable error/report file if practical
- no macros executed
- no direct parser-to-database writes

---

# 13. Enquiries

Preserve the Admin-first rule.

An operator can see an enquiry only after Admin approval / operator dispatch.

Operator Portal should provide:

- inbox/list
- filters by status/date/product
- detail view
- customer request details appropriate for operator
- internal status history
- allowed transitions
- reply/note/quote metadata where implemented
- audit and notification events

Allowed operator transitions should remain explicit.

Operators must not:

- access another organisation's enquiries
- see pending Admin-review enquiries
- bypass the Admin approval workflow
- change Admin-only statuses arbitrarily

Phase 3 does not require a new payment/transaction booking engine.

---

# 14. Notifications

Expose the Phase 2B reusable notification system to operators.

Required:

- operator recipient/audience notifications
- unread count
- mark read
- actionable links
- product/enquiry/import context
- organisation isolation
- notification history pagination
- no separate operator-only notification subsystem

Potential events:

- enquiry sent to operator
- import completed/failed
- availability conflict involving operator source
- claim/member invitation
- verification/content review outcome
- offer approaching expiry where configured

Email remains a channel, not business logic embedded in controllers.

---

# 15. Moderation & Publication Boundary

Phase 3 must explicitly define which operator edits are:

### Immediate operational updates

Normally:

- availability
- price overrides
- offers
- departure dates/status
- room availability
- stop-sell
- enquiry responses

### Potentially moderated catalogue edits

May include:

- vessel/resort identity
- major descriptive content
- ownership-sensitive fields
- selected media
- significant itinerary/property facts

The precise moderation policy may be configurable, but Phase 3 must not give operators control over:

- Deeparture verification state
- Deeparture vegan/editorial ratings
- publication/restriction/archive authority unless explicitly allowed
- editorial ranking/featured state

Where moderation is required, save proposed changes without destroying the last approved public version.

---

# 16. API & Service Rules

Prefer dedicated operator routes/service methods over exposing Admin APIs.

Recommended route boundary:

```text
/api/v2/operator/...
```

or an equivalent clearly operator-scoped module.

All operator routes must:

- use V2 auth
- resolve organisation membership
- check capability
- check resource ownership
- use shared domain services
- produce audit events
- use consistent error contract
- include operation IDs for multi-step work
- paginate growing lists
- enforce bounded page sizes
- support optimistic conflict handling where material

Avoid business logic in React pages.

Use a shared frontend API client/service layer.

---

# 17. Security Requirements

Phase 3 has a higher security burden because external supplier users now receive broad editing capability.

Mandatory tests:

- Operator A cannot read private Operator B resources
- Operator A cannot update Operator B vessel
- Operator A cannot update Operator B resort
- Operator A cannot edit Operator B itinerary/departure
- Operator A cannot alter Operator B pricing/availability/offers
- Operator A cannot see Operator B enquiries
- Operator A cannot access Operator B import history
- Operator A cannot manage Operator B users
- Operator A cannot attach media to Operator B records
- changing an ID in URL/body cannot bypass ownership checks
- organisation ownership cannot be transferred by body payload
- suspended organisation/member loses write access
- read-only user cannot write
- reservations user cannot manage organisation members
- content role cannot gain pricing/availability permissions accidentally

Also:

- sanitize rich text
- validate upload MIME/extension/size
- do not execute spreadsheet macros
- rate-limit auth, invitations and imports where appropriate
- never expose secrets/tokens/password hashes
- claim/member invitations are expiring/single-use

---

# 18. Mobile-First Requirement

Phase 3 should be designed for phone use, not merely responsive shrinking.

At minimum, a phone user should comfortably:

- update availability
- mark sold out/on request
- update a price
- create/expire an offer
- respond to an enquiry
- upload/select an image
- review an import preview
- see notifications
- switch between owned products

Avoid wide desktop-only tables for high-frequency workflows.

Use cards, drawers, compact row editors, sticky save/actions and touch-friendly controls where appropriate.

Acceptance widths should include approximately:

```text
390 px
768 px
1440 px
```

---

# 19. Concurrency, Audit & Engineering Guardrails

Phase 3 inherits all Phase 2B Rev 1.3 guardrails.

Required:

- documented migrations/backfills and rollback/recovery
- indexes for operator lists/inventory/enquiries/imports
- server-side pagination/sorting
- bounded page sizes
- optimistic concurrency where material
- explicit conflict responses
- stable API error contract
- operation/correlation IDs
- bounded bulk actions
- per-record/partial outcomes
- audit/provenance
- retention readiness
- realistic seeded-data performance checks
- no unnecessary heavy infrastructure

Do not add Redis, Elasticsearch/OpenSearch, Kafka, Kubernetes or microservices unless actual evidence requires them.

---

# 20. Future Integration Readiness

Phase 3 prepares operator-owned data for Phase 5 integrations.

Support stable external mapping fields and operator-owned external IDs where useful.

Do not build actual external booking-system connectors in Phase 3.

Future flow remains:

```text
external supplier system
-> adapter/connector
-> normalized Deeparture contract
-> existing catalogue/pricing/availability service
```

Operator manual edits and future API/feed updates must converge on the same service boundaries.

---

# 21. Non-Goals

Not required for Phase 3:

- polished public/customer marketplace redesign
- full customer faceted search UI
- PWA implementation
- native iOS/Android app
- Agent Portal
- production V1 cutover
- external booking-system integrations
- automated website extraction
- scheduled supplier sync framework
- payment gateway / transactional booking engine
- enterprise message bus
- separate operator-specific pricing/availability subsystem

---

# 22. Recommended Implementation Sequence

1. freeze/record final Phase 2B corrected Git commit
2. capability permission layer + migration compatibility
3. operator shell/navigation/API client
4. onboarding/claim completion
5. organisation users
6. liveaboard editors
7. resort editors
8. availability/pricing/offers quick workflows
9. operator import preview/confirm/history
10. media manager/storage adapter
11. enquiries
12. notifications
13. mobile polish
14. security/regression/performance testing
15. Render + Atlas staging acceptance

---

# 23. Phase 3 Completion Criteria

Phase 3 is complete when:

- one claimed organisation can manage both liveaboards and resorts
- multiple organisation users can work under controlled permissions
- cross-organisation access is prevented
- operator cannot change Deeparture-controlled editorial fields
- vessel/resort modular editing works
- liveaboard itineraries/departures/pricing/availability/offers work
- resort rooms/packages/rates/availability/stop-sell/offers work
- media upload/management uses persistent storage abstraction
- operator imports preview before write and reuse normalized import/history
- enquiries preserve Admin-first workflow
- operator notifications reuse Phase 2B notification service
- routine workflows are usable on phone/tablet/desktop
- Phase 1 + Phase 2 regressions remain green
- dedicated Atlas staging is used
- exact branch/commit deployed to Render is recorded
- Phase 3 acceptance checklist passes

---

# 24. Architectural Standard

A Phase 3 feature is correctly implemented when it looks like:

```text
Operator UI
-> operator-scoped API
-> membership + capability + ownership authorization
-> existing shared/product service
-> audited domain write
-> existing database model
```

and not:

```text
Operator UI
-> special operator-only business logic
-> parallel database/service path
```
